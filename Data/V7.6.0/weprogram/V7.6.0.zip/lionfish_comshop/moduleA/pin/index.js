var util = require('../../utils/util.js');
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    classification: {
      tabs: [],
      activeIndex: 0
    },
    slider_list: [],
    pintuan_show_type: 0,
    loadMore: true,
    loadText: "加载中...",
    loadOver: false,
    showEmpty: false,
    rushList: [],
    isIpx: app.globalData.isIpx
  },
  pageNum: 1,

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initFn();
  },

  initFn: function(){
    wx.showLoading();
    this.getTabs();
    this.getData();
  },

  authSuccess: function () {
    let that = this;
    this.pageNum = 1;
    this.setData({
      classification: {
        tabs: [],
        activeIndex: 0
      },
      slider_list: [],
      pintuan_show_type: 0,
      loadMore: true,
      loadText: "加载中...",
      loadOver: false,
      showEmpty: false,
      rushList: []
    }, () => {
      that.initFn();
    })
  },

  authModal: function () {
    if (this.data.needAuth) {
      this.setData({ showAuthModal: !this.data.showAuthModal });
      return false;
    }
    return true;
  },

  /**
   * 获取分类
   */
  getTabs: function () {
    let that = this;
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'group.pintuan_slides'
      },
      dataType: 'json',
      success: function (res) {
        if(res.data.code==0) {
          let { category_list, pintuan_show_type, slider_list, tabbar_out_type, open_tabbar_out_weapp } = res.data;
          category_list = category_list || [];
          let index_type_first_name = '推荐';

          if (category_list.length > 0) {
            category_list.unshift({
              name: index_type_first_name,
              id: 0
            })
            that.setData({
              isShowClassification: true,
              "classification.tabs": category_list,
              slider_list: slider_list || [],
              pintuan_show_type,
              tabbar_out_type,
              open_tabbar_out_weapp
            })
          } else {
            that.setData({
              isShowClassification: false,
              slider_list: slider_list || [],
              pintuan_show_type,
              tabbar_out_type,
              open_tabbar_out_weapp
            })
          }
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 监控分类导航
   */
  classificationChange: function (t) {
    console.log(t.detail.e)
    wx.showLoading();
    var that = this;
    this.pageNum = 1;
    this.setData({
      rushList: [],
      showEmpty: false,
      "classification.activeIndex": t.detail.e,
      classificationId: t.detail.a
    }, function () {
      that.getData();
    });
  },

  /**
   * 获取商品列表
   */
  getData: function () {
    let that = this;
    let token = wx.getStorageSync('token');
    let gid = that.data.classificationId;
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'group.get_pintuan_list',
        pageNum: this.pageNum,
        gid,
        token
      },
      dataType: 'json',
      success: function (res) {
        wx.hideLoading();
        wx.stopPullDownRefresh();
        if (res.data.code == 0) {
          let oldRushList = that.data.rushList;
          let h = {}, list = res.data.list;
          if (that.pageNum == 1 && list.length == 0) h.showEmpty = true;
          let rushList = oldRushList.concat(list);
          let rdata = res.data;
          let reduction = { full_money: rdata.full_money, full_reducemoney: rdata.full_reducemoney, is_open_fullreduction: rdata.is_open_fullreduction }
          h.rushList = rushList;
          h.reduction = reduction;
          h.loadOver = true;
          h.loadText = that.data.loadMore ? "加载中..." : "没有更多商品了~";
          that.setData(h, function () {
            that.pageNum += 1;
          })
        } else if (res.data.code == 1) {
          let s = { loadMore: false }
          if (that.pageNum == 1)  s.showEmpty = true;
          that.setData(s);
        } else if (res.data.code == 2) {
          //no login
          that.setData({ needAuth: true })
        }
      }
    })
  },

  /**
   * 幻灯片跳转
   */
  goBannerUrl: function (t) {
    let idx = t.currentTarget.dataset.idx;
    let { slider_list, needAuth } = this.data;
    if (slider_list.length > 0) {
      let url = slider_list[idx].link;
      let type = slider_list[idx].linktype;
      if (util.checkRedirectTo(url, needAuth)) {
        this.authModal();
        return;
      }
      if (type == 0) {
        // 跳转webview
        url && wx.navigateTo({ url: '/lionfish_comshop/pages/web-view?url=' + encodeURIComponent(url) })
      } else if (type == 1) {
        if (url.indexOf('lionfish_comshop/pages/index/index') != -1 || url.indexOf('lionfish_comshop/pages/order/shopCart') != -1 || url.indexOf('lionfish_comshop/pages/user/me') != -1 || url.indexOf('lionfish_comshop/pages/type/index') != -1) {
          url && wx.switchTab({ url: url })
        } else {
          url && wx.navigateTo({ url: url })
        }

      } else if (type == 2) {
        // 跳转小程序
        let appid = slider_list[idx].appid;
        appid && wx.navigateToMiniProgram({
          appId: slider_list[idx].appid,
          path: url,
          extraData: {},
          envVersion: 'release',
          success(res) {
            // 打开成功
          },
          fail(error) {
            console.log(error)
          }
        })
      }
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    let that = this;
    this.pageNum = 1;
    this.setData({
      loadMore: true,
      loadText: "加载中...",
      loadOver: false,
      showEmpty: false,
      rushList: []
    }, () => {
      that.getData();
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log('这是我的底线');
    this.data.loadMore && (this.setData({ loadOver: false }), this.getData());
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})