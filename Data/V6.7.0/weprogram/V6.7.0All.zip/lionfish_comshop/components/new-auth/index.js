var util = require('../../utils/util.js');
var location = require('../../utils/Location.js');
var app = getApp();

Component({
  properties: {
    needAuth: {
      type: Boolean,
      value: false
    },
    needPosition: {
      type: Boolean,
      value: true
    },
    navBackUrl: {
      type: String,
      value: '',
      observer: function (t) {
        if (t) app.globalData.navBackUrl = t;
      }
    }
  },
  data: {
    btnLoading: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  methods: {
    close: function () {
      this.triggerEvent("cancel");
    },
    bindGetUserInfo: function (t) {
      var that = this;
      if (!this.data.btnLoading) {
        var n = t.detail;
        if (this.setData({ btnLoading: true }), "getUserInfo:ok" === n.errMsg) {
          util.login_prosime(that.data.needPosition).then(function () {
            console.log("授权成功")
            that.setData({ btnLoading: false });
            wx.showToast({
              title: '登录成功',
              icon: 'success',
              duration: 2000
            })
            that.triggerEvent("authSuccess");
            app.globalData.changedCommunity = true;
            //检查获取位置权限
            that.data.needPosition && location.getGps();
          }).catch(function () {
            this.triggerEvent("cancel");
            console.log('授权失败');
          })
        } else {
          wx.showToast({
            title: "授权失败，为了完整体验，获取更多优惠活动，需要您的授权。",
            icon: "none"
          });
          this.triggerEvent("cancel");
          this.setData({ btnLoading: false });
        }
      }
    }
  }
});