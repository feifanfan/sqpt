// lionfish_comshop/pages/groupCenter/index.js
var app = getApp();
var status = require('../../utils/index.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    waitSendNum: 0,
    waitSignNum: 0,
    waitPickNum: 0,
    completeNum: 0,
    disUserId: "",
    communityName: "",
    communityId: "",
    distribution: "",
    estimate: "",
    lastMonth: "",
    isShow: true,
    currentTab: 0,
    show_on_one:0,
    dialogShow: 0,
    effectValidOrderNum: 0,
    groupInfo: {
      group_name: '社区',
      owner_name: '团长'
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    status.setGroupInfo().then((groupInfo) => {
      let owner_name = groupInfo && groupInfo.owner_name || '团长';
      wx.setNavigationBarTitle({
        title: `${owner_name}中心`,
      })
      that.setData({ groupInfo })
    });
    this.loadPage();
  },

  loadPage: function () {
    let that = this;
    status.loadStatus().then(function () {
      let appLoadStatus = app.globalData.appLoadStatus;
      if (appLoadStatus == 0) {
        wx.redirectTo({
          url: "/lionfish_comshop/pages/auth/index"
        })
      } else if (appLoadStatus == 2) {
       // wx.redirectTo({
        //  url: "/lionfish_comshop/pages/position/community"
       // })
      }
      that.setData({
        appLoadStatus: appLoadStatus,
        community: app.globalData.community
      })
    });
    this.load_community_data();
  },
  load_community_data:function(){
    var token = wx.getStorageSync('token');
    var that = this;
    app.util.request({
      'url': 'entry/wxapp/user',
      'data': {
        controller: 'community.get_community_info',
        'token': token
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          let communityData = res.data;
          let commission_info = communityData.commission_info;
          commission_info.mix_total_money = commission_info.mix_total_money.toFixed(2);
          let { head_today_pay_money, today_add_head_member, today_after_sale_order_count, today_invite_head_member } = res.data;
          that.setData({
            member_info: communityData.member_info,
            community_info: communityData.community_info,
            commission_info: commission_info,
            total_order_count: communityData.total_order_count || 0,
            total_member_count: communityData.total_member_count || 0,
            today_order_count: communityData.today_order_count || 0,
            today_effect_order_count: communityData.today_effect_order_count || 0,
            today_pay_order_count: communityData.today_pay_order_count || 0,
            today_pre_total_money: communityData.today_pre_total_money || 0,
            waitSendNum: communityData.wait_send_count || 0,
            waitSignNum: communityData.wait_qianshou_count || 0,
            waitPickNum: communityData.wait_tihuo_count || 0,
            completeNum: communityData.has_success_count || 0,
            open_community_addhexiaomember: communityData.open_community_addhexiaomember,
            open_community_head_leve: communityData.open_community_head_leve,
            head_today_pay_money,
            today_add_head_member, 
            today_after_sale_order_count, 
            today_invite_head_member
          });
        } else {
          //is_login
          wx.reLaunch({
            url: '/lionfish_comshop/pages/user/me',
          })
        }
      }
    })
  },

  /**
   * 扫描
   */
  goScan: function(){
    wx.scanCode({
      success(res) {
        console.log(res)
        if (res.scanType == 'WX_CODE' && res.path != '')
        {
          wx.navigateTo({
            url: "/" + res.path
          });
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var show_on_one = this.data.show_on_one;
    if (show_on_one > 0)
    {
      this.load_community_data();
    }
    this.setData({
      show_on_one: 1
    })
  },

  /**
   * 跳转订单
   */
  goOrder: function (e) {
    let status = e.currentTarget.dataset.status;
    wx.navigateTo({
      url: "/lionfish_comshop/pages/groupCenter/groupList?tab=" + status
    });
  },

  /**
   * 跳转编辑
   */
  goEdit: function () {
    wx.navigateTo({
      url: "/lionfish_comshop/pages/groupCenter/setting?id=" + this.data.community_info.id
    });
  },

  /**
   * 导航切换
   */
  switchNav: function (e) {
    if (this.data.currentTab === 1 * e.target.dataset.current) return false;
    this.setData({
      currentTab: 1 * e.target.dataset.current
    });
  },

  /**
   * 导航切换监控
   */
  bindChange: function (e) {
    this.setData({
      currentTab: 1 * e.detail.current
    });
    for (var i = 0; i < 4; i++) {
      if (this.data.currentTab === i) {
        this.setData({
          effectEstimate: this.data.effectList[i].estimate,
          effectSettle: this.data.effectList[i].settle,
          effectValidOrderNum: this.data.effectList[i].validOrderNum
        });
      }
    }
  }
})