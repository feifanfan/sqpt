var t = Object.assign || function (t) {
  for (var a = 1; a < arguments.length; a++) {
    var e = arguments[a];
    for (var u in e) Object.prototype.hasOwnProperty.call(e, u) && (t[u] = e[u]);
  }
  return t;
}, a = require("../../utils/public"), e = getApp();

Component({
  properties: {
    visible: {
      type: Boolean,
      value: false,
      observer: function (t) {
        t && this.setData({
          value: 1,
          loading: false
        });
      }
    },
    skuList: {
      type: Array,
      value: [{
          "list": [{
            "goods_option_id": "15",
            "option_id": "15",
            "name": "尺码",
            "option_value": [{
              "goods_option_value_id": "30",
              "option_value_id": "30",
              "name": "XL",
              "image": ""
            }, {
              "goods_option_value_id": "29",
              "option_value_id": "29",
              "name": "M",
              "image": ""
            }]
          }, {
            "goods_option_id": "16",
            "option_id": "16",
            "name": "尺码",
            "option_value": [{
              "goods_option_value_id": "32",
              "option_value_id": "32",
              "name": "XL",
              "image": "https:\/\/shiziyu.liofis.com\/attachment\/images\/3\/2018\/12\/sZjsKytoyYKTOOPzLkE56RK65csGrj.png"
            }, {
              "goods_option_value_id": "31",
              "option_value_id": "31",
              "name": "M",
              "image": "https:\/\/shiziyu.liofis.com\/attachment\/images\/3\/2018\/12\/KO66uCjozjrjf0cSu6RfrZrKU6K6Yr.jpeg"
            }]
          }],
          "name": ["尺码", "尺码"],
          "sku_mu_list": [{
            "spec": "M+M",
            "canBuyNum": "22",
            "spuName": "大毛领短款羊剪绒外套女显瘦2018冬季新款加厚仿水貂绒毛呢外套女",
            "actPrice": ["1", "50"],
            "marketPrice": ["2", "00"],
            "skuImage": "https:\/\/shiziyu.liofis.com\/attachment\/images\/3\/2018\/12\/KO66uCjozjrjf0cSu6RfrZrKU6K6Yr.jpeg"
          }, {
            "spec": "M+XL",
            "canBuyNum": "22",
            "spuName": "大毛领短款羊剪绒外套女显瘦2018冬季新款加厚仿水貂绒毛呢外套女",
            "actPrice": ["2", "00"],
            "marketPrice": ["2", "00"],
            "skuImage": "https:\/\/shiziyu.liofis.com\/attachment\/images\/3\/2018\/12\/sZjsKytoyYKTOOPzLkE56RK65csGrj.png"
          }, {
            "spec": "XL+M",
            "canBuyNum": "22",
            "spuName": "大毛领短款羊剪绒外套女显瘦2018冬季新款加厚仿水貂绒毛呢外套女",
            "actPrice": ["3", "00"],
            "marketPrice": ["2", "00"],
            "skuImage": "https:\/\/shiziyu.liofis.com\/attachment\/images\/3\/2018\/12\/KO66uCjozjrjf0cSu6RfrZrKU6K6Yr.jpeg"
          }, {
            "spec": "XL+XL",
            "canBuyNum": "22",
            "spuName": "大毛领短款羊剪绒外套女显瘦2018冬季新款加厚仿水貂绒毛呢外套女",
            "actPrice": ["4", "00"],
            "marketPrice": ["2", "00"],
            "skuImage": "https:\/\/shiziyu.liofis.com\/attachment\/images\/3\/2018\/12\/sZjsKytoyYKTOOPzLkE56RK65csGrj.png"
          }]
      }],
      observer: function (t) {
        
        if (t && t.length) {
          console.log('t.length');
          console.log(t.length);
          for (var a = t, e = "", u = 0; u < a.length; u++) if (a[u].canBuyNum - 1 >= 0) {
            e = u;
            break;
          }
          "number" == typeof e ? this.setData({
            current: e,
            canBuyFlag: true
          }) : this.setData({
            canBuyFlag: false,
            current: 0
          });
        }
      }
    },
    promotionDTO: Object,
    current: {
      type: Number,
      value: 0
    },
    type: {
      type: Number,
      value: 0
    }
  },
  data: {
    value: 1,
    cur_option_idx:"",
    canBuyMsg: "",
    loading: false,
    canBuyFlag: !0,
    focusFlag: false
  },
  methods: {
    close: function () {
      this.triggerEvent("cancel");
    },
    switchSpec: function (t) {
      this.data.focusFlag || t.target.dataset.disabled || this.data.current !== 1 * t.target.dataset.idx && this.canBuyFn(1, t.target.dataset.idx, {
        current: t.target.dataset.idx
      });
    },
    focus: function () {
      this.data.focusFlag = !0;
    },
    canBuyFn: function (a, e) {
      var u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, i = this.data.skuList[e].canBuyNum - a, s = {
        value: a
      };
      i <= 10 && (s.canBuyMsg = "还可以购买 " + i + " 件"), this.data.canBuyMsg && i > 10 && (s.canBuyMsg = ""),
        this.setData(t({}, s, u));
    },
    changeNumber: function (t) {
      var a = t.detail;
      this.data.focusFlag = false, a && this.canBuyFn(a.value, this.data.current);
    },
    confirm: function () {
      var t = this;
      if (this.setData({
        loading: !0
      }), this.data.canBuyFlag) {
        var u = this.data.current, i = this.data.skuList, s = {
          actId: i[u].actId,
          skuId: i[u].skuId,
          goodsNum: this.data.value,
          spuId: i[u].spuId
        }, n = i[u].actId, r = i[u].skuId, c = this.data.value, o = i[u].spuId, d = e.globalData.community.communityId;
        0 === this.data.type ? (0, a.addToCart)({
          actId: n,
          communityId: e.globalData.community.communityId,
          goodsNum: c,
          skuId: r
        }, function () {
          t.triggerEvent("confirm");
        }) : 1 === this.data.type ? (0, a.skuConfirm)({
          communityId: d,
          skuInfo: [{
            skuNum: c,
            skuId: r,
            actId: n,
            spuId: o
          }]
        }, function () {
          t.triggerEvent("confirm");
        }) : this.triggerEvent("confirm", s);
      } else wx.showToast({
        title: "该商品已失效",
        icon: "none"
      });
    }
  }
});