const app = getApp()
var util = require('../../utils/util.js');
var WxParse = require('../../wxParse/wxParse.js');
var status = require('../../utils/index.js');

Page({
  mixins: [require('../../mixin/compoentCartMixin.js')],
  data: {
    info: {}
  },
  gid: 0,

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let gid = options.id || '';
    this.gid = gid;
    this.getData(gid);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const that = this;
    util.check_login_new().then((res) => {
      let needAuth = !res;
      that.setData({ needAuth })
      if (res) {
        (0, status.cartNum)('', true).then((res) => {
          res.code == 0 && that.setData({
            cartNum: res.data
          })
        });
      }
    })
  },

  /**
   * 授权成功回调
   */
  authSuccess: function () {
    const that = this;
    let gid = this.gid;
    this.setData({
      needAuth: false,
      showAuthModal: false
    }, () => {
      that.getData(gid);
    })
  },

  /**
   * 获取信息
   */
  getData: function (id) {
    let that = this;
    let token = wx.getStorageSync('token');
    let community = wx.getStorageSync('community');
    let head_id = community.communityId || '';

    wx.showLoading();
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'recipe.get_recipe_detail',
        token,
        id,
        head_id
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code==0) {
          let info = res.data.data || {};
          var article = info.content;
          WxParse.wxParse('article', 'html', article, that, 0, app.globalData.systemInfo);
          that.setData({ info })
        }
        wx.hideLoading();
      }
    })
  },

  /**
   * 点赞
   */
  agree: function () {
    if (!this.authModal()) return;
    let that = this;
    let item = this.data.info;
    let token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'recipe.fav_recipe_do',
        token: token,
        id: item.id
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          //成功
          wx.showToast({
            title: '已喜欢~',
            icon: 'none'
          })
          item.fav_count = res.data.fav_count;
          item.has_fav = 1;
          that.setData({ info: item })
        } else if (res.data.code == 1) {
          //未登录
          that.setData({ needAuth: true });
        } else if (res.data.code == 2) {
          //取消收藏
          item.fav_count = res.data.fav_count;
          item.has_fav = 0;
          that.setData({ info: item })
          wx.showToast({
            title: '取消喜欢~',
            icon: 'none'
          })
        }
      }
    })
  },

  goLink: function(e){
    let link = e.currentTarget.dataset.link;
    app.util.navTo(link);
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})