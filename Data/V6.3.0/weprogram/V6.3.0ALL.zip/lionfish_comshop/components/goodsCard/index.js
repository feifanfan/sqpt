// lionfish_comshop/components/goodsCard/index.js
var e = require("../../utils/timeFormat");
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    status: {
      type: Number
    },
    orderNo: {
      type: String
    },
    orderArray: {
      type: Array,
      observer: function (itemArr) {
        var orderSkuStatus = itemArr[0].orderSkuStatus, 
          itemObj = itemArr[0], 
          a = itemObj.pickUpTime, 
          i = itemObj.realPickUpTime, 
          s = {}, 
          m = {}, 
          len = 0;
        a && (s = (0, e.formatWeekday)(new Date(a - 0))), 
        i && (m = (0, e.formatWeekday)(new Date(i - 0)));
        for (var n = 0; n < itemArr.length; n++) len += itemArr[n].skuNum;
        this.setData({
          showPickUpTime: s.month + "月" + s.day + "日(" + s.weekday + ")",
          showRealPickUpTime: m.month + "月" + m.day + "日(" + m.weekday + ")",
          len: len,
          orderSkuStatus: orderSkuStatus
        });
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    showPickUpTime: "",
    showRealPickUpTime: "",
    len: 0,
    orderSkuStatus: 0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    goodsConfirmed: function () {
      this.triggerEvent("goodsConfirmed");
    }
  }
})
