var app = getApp();
var util = require('../../utils/util.js');

Page({
  mixins: [require('../../mixin/cartMixin.js')],
  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    info: []
  },
  id: 0,

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id = options.id || 0;
    this.id = id;
    if (util.check_login()) {
      this.setData({ needAuth: false })
      this.getData(id);
    } else {
      this.setData({ needAuth: true });
    }
  },

  /**
   * 授权成功回调
   */
  authSuccess: function () {
    this.getData(this.id);
    this.setData({
      needAuth: false
    })
  },

  getData: function (id) {
    var token = wx.getStorageSync('token');
    var that = this;
    var cur_community = wx.getStorageSync('community');
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'marketing.get_special',
        token,
        head_id: cur_community.communityId,
        id
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          let list = res.data.list;
          let info = res.data.data;
          wx.setNavigationBarTitle({
            title: info.special_title || '专题'
          })
          that.setData({ list, info })
        } else if (res.data.code == 1) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
            showCancel: false,
            success(ret){
              if (ret.confirm) {
                wx.switchTab({
                  url: '/lionfish_comshop/pages/index/index',
                })
              }
            }
          })
        } else if(res.data.code == 2) {
          // 未登录
          that.setData({ needAuth: true });
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  }
})