// lionfish_comshop/components/vipPrice.js
Component({
  properties: {
    price: {
      type: String,
      value: '0'
    }
  }
})
