Component({
  properties: {
    visible: {
      type: Boolean,
      value: true
    }
  },

  data: {
    isAccept: true, // 防止静态先显现出来
  },

  methods: {
    /**
     * 订阅
     */
    subscriptionNotice: function() {
      wx.vibrateShort();
      let that = this;
      let id = 'xxxxx'; // 订阅消息模版id
      if (wx.requestSubscribeMessage) {
        wx.requestSubscribeMessage({
          tmplIds: [id],
          success(res) {
            if (res[id] == 'accept') {
              //用户同意了订阅，添加进数据库
              that.addAccept()
            } else {
              //用户拒绝了订阅或当前游戏被禁用订阅消息
              wx.showToast({
                title: '订阅失败',
                icon: 'none'
              })
              that.setData({ visible: false })
            }
          },
          fail(res) {
            console.log(res)
          },
          complete(res) {
            console.log(res)
          }
        })
      } else {
        // 兼容处理
        wx.showModal({
          title: '提示',
          content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
        })
        this.setData({ visible: false })
      }
    },

    // 用户点击订阅添加到数据库
    addAccept: function () {
      console.log('入notices库成功', res);
      // this.setData({
      //   isAccept: true
      // }, () => {
      //   wx.showToast({
      //     title: '订阅成功'
      //   })
      // })
    },
    /**
     * 订阅状态查询
     */
    checkIsAccept: function (id) {
      let that = this;
      // that.setData({
      //   isAccept: false
      // })
    }
  }
})
