// lionfish_comshop/components/goodsInfo/index.js
Component({
  properties: {
    order: {
      type: Object
    },
    showNickname: {
      type: Boolean,
      default: false
    }
  },
  data: {
    isCalling: false
  },
  methods: {
    callTelphone: function(t) {
      var e = this;
      this.data.isCalling || (this.data.isCalling = true, wx.makePhoneCall({
        phoneNumber: t.currentTarget.dataset.phone,
        complete: function() {
          e.data.isCalling = false;
        }
      }));
    }
  }
})