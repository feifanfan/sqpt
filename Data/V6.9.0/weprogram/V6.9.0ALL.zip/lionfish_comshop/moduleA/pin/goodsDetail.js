// lionfish_comshop/pages/goods/goodsDetail.js
var util = require('../../utils/util.js');
var status = require('../../utils/index.js');

var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
var detailClearTime = null;

function count_down(that, total_micro_second) {
  var second = Math.floor(total_micro_second / 1000);
  var days = second / 3600 / 24;
  var daysRound = Math.floor(days);
  var hours = second / 3600 - (24 * daysRound);
  var hoursRound = Math.floor(hours);
  var minutes = second / 60 - (24 * 60 * daysRound) - (60 * hoursRound);
  var minutesRound = Math.floor(minutes);
  var seconds = second - (24 * 3600 * daysRound) - (3600 * hoursRound) - (60 * minutesRound);

  that.setData({
    endtime: {
      days: fill_zero_prefix(daysRound),
      hours: fill_zero_prefix(hoursRound),
      minutes: fill_zero_prefix(minutesRound),
      seconds: fill_zero_prefix(seconds),
      show_detail: 1
    }
  });

  if (total_micro_second <= 0) {
    clearTimeout(detailClearTime);
    detailClearTime = null;
    if (that.data.goods.over_type == 0) {
      that.authSuccess();
    }
    that.setData({
      endtime: {
        days: "00",
        hours: "00",
        minutes: "00",
        seconds: "00",
      }
    });
    return;
  }

  detailClearTime = setTimeout(function() {
    total_micro_second -= 1000;
    count_down(that, total_micro_second);
  }, 1000)

}
// 位数不足补零
function fill_zero_prefix(num) {
  return num < 10 ? "0" + num : num
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    needAuth: false,
    goodsIndex: 1,
    goods_id: 0,
    endtime: {
      days: "00",
      hours: "00",
      minutes: "00",
      seconds: "00",
    },
    imageSize: {
      imageWidth: "100%",
      imageHeight: 600
    },
    cartNum: 0,
    noIns: false,
    index_bottom_image: '',
    hideModal: true,
    shareImgUrl: '',
    goods_details_middle_image: '',
    is_show_buy_record: 0,
    stopNotify: true,
    iconArr: {
      home: '',
      car: ''
    },
    canvasWidth: 375,
    canvasHeight: 300,
    fmShow: true,
    relative_goods_list: [],
    needPosition: false
  },
  $data: {
    id: '',
    scene: '',
    community_id: 0
  },
  imageUrl: '',
  goodsImg: '',
  currentOptions: [],

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    status.setNavBgColor();
    status.setIcon().then(function(iconArr) {
      that.setData({
        iconArr
      });
    });
    var token = wx.getStorageSync('token');
    var scene = decodeURIComponent(options.scene);
    this.$data.id = options.id;
    this.$data.community_id = options.community_id;
    this.$data.scene = options.scene;
    let currentCommunity = wx.getStorageSync('community');
    let currentCommunity_id = (currentCommunity && currentCommunity.communityId) || '';
    wx.showLoading();

    if (!currentCommunity_id) {
      let community = {};
      if (options.community_id !== 'undefined' && options.community_id > 0) {
        community.communityId = options.community_id;
      }
      if (scene !== 'undefined') {
        var opt_arr = scene.split("_");
        options.community_id = opt_arr[2];
        community.communityId = options.community_id;
      }
      util.getCommunityInfo(community).then(function(res) {
        console.log('step1')
        paramHandle();
        get_goods_details(res);
      }).catch((param) => {
        console.log('step4 新人')
        if (Object.keys(param) != '') that.addhistory(param, true);
      });
    } else {
      console.log('step3')
      paramHandle();
      get_goods_details(currentCommunity);
    }

    if (options.share_id != 'undefined' && options.share_id > 0) wx.setStorage({
      key: "share_id",
      data: options.share_id
    })

    function paramHandle() {
      console.log('step2')
      if (options.community_id != 'undefined' && options.community_id > 0) getCommunityInfo(options.community_id);
      if (scene != 'undefined') {
        //$goods_id.'_'.$member_id_community_id
        var opt_arr = scene.split("_");
        options.id = opt_arr[0];
        wx.setStorage({
          key: "share_id",
          data: opt_arr[1]
        })
        getCommunityInfo(opt_arr[2]);
      }

      function getCommunityInfo(c_id) {
        app.util.request({
          'url': 'entry/wxapp/index',
          'data': {
            controller: 'index.get_community_info',
            community_id: c_id
          },
          dataType: 'json',
          success: function(res) {
            if (res.data.code == 0) {
              var community = res.data.data;
              let hisCommunity = currentCommunity;
              let community_id = currentCommunity_id;
              if (c_id != community_id) {
                wx.showModal({
                  title: '温馨提示',
                  content: '是否切换为分享人所在小区“' + community.communityName,
                  confirmColor: '#F75451',
                  success(res) {
                    if (res.confirm) {
                      app.globalData.community = community;
                      app.globalData.changedCommunity = true;
                      wx.setStorage({
                        key: "community",
                        data: community
                      })
                      token && that.addhistory(community);
                      get_goods_details(community);
                      console.log('用户点击确定')
                    } else if (res.cancel) {
                      that.showNoBindCommunity();
                      console.log('用户点击取消')
                    }
                  }
                })
              } else {
                console.log('step5')
                let oldCommunity = wx.getStorageSync('community');
                if (!oldCommunity) {
                  app.globalData.community = community;
                  app.globalData.changedCommunity = true;
                  wx.setStorage({
                    key: "community",
                    data: community
                  })
                }
              }
            }
          }
        })
      }

      that.setData({
        goods_id: options.id
      })
    }

    function get_goods_details(communityInfo) {
      if (!options.id) {
        wx.hideLoading();
        wx.showModal({
          title: '提示',
          content: '参数错误',
          showCancel: false,
          confirmColor: '#F75451',
          success(res) {
            if (res.confirm) {
              wx.redirectTo({
                url: '/lionfish_comshop/pages/index/index',
              })
            }
          }
        })
        return false;
      }
      if (communityInfo) currentCommunity_id = communityInfo.communityId;
      app.util.request({
        url: 'entry/wxapp/index',
        data: {
          controller: 'goods.get_goods_detail',
          token: token,
          id: options.id,
          community_id: currentCommunity_id
        },
        dataType: 'json',
        success: function(res) {
          wx.hideLoading();
          let goods = res.data.data.goods;
          // 商品不存在
          if (!goods || goods.length == 0 || Object.keys(goods) == '') {
            wx.showModal({
              title: '提示',
              content: '该商品不存在，回首页',
              showCancel: false,
              confirmColor: '#F75451',
              success(res) {
                if (res.confirm) {
                  wx.switchTab({
                    url: '/lionfish_comshop/pages/index/index',
                  })
                }
              }
            })
          }
          let comment_list = res.data.comment_list;
          comment_list.map(function(item) {
            14 * item.content.length / app.globalData.systemInfo.windowWidth > 3 && (item.showOpen = true), item.isOpen = true;
          })

          // 幻灯片预览数组
          let goods_images = res.data.data.goods_image;
          let prevImgArr = [];
          goods_images.forEach(function(item) {
            prevImgArr.push(item.image);
          })

          //群分享
          let isopen_community_group_share = res.data.isopen_community_group_share || 0;
          let group_share_info = res.data.group_share_info;

          // 关联商品
          let relative_goods_list = res.data.data.relative_goods_list || [];
          let relative_goods_list_arr = [];
          if (Object.prototype.toString.call(relative_goods_list) == '[object Object]' && Object.keys(relative_goods_list).length > 0) {
            Object.keys(relative_goods_list).forEach(function(item) {
              relative_goods_list_arr.push(relative_goods_list[item]);
            })
          } else {
            relative_goods_list_arr = relative_goods_list;
          }

          that.currentOptions = res.data.data.options;
          that.setData({
            order_comment_count: res.data.order_comment_count,
            comment_list: comment_list,
            goods: goods,
            options: res.data.data.options,
            order: {
              goods_id: res.data.data.goods.goods_id,
              pin_id: res.data.data.pin_id,
            },
            share_title: goods.share_title,
            buy_record_arr: res.data.data.buy_record_arr,
            goods_image: res.data.data.goods_image,
            goods_image_length: res.data.data.goods_image.length,
            service: goods.tag,
            showSkeleton: false,
            is_comunity_rest: res.data.is_comunity_rest,
            prevImgArr,
            open_man_orderbuy: res.data.open_man_orderbuy,
            man_orderbuy_money: res.data.man_orderbuy_money,
            goodsdetails_addcart_bg_color: res.data.goodsdetails_addcart_bg_color || 'linear-gradient(270deg, #f9c706 0%, #feb600 100%)',
            goodsdetails_buy_bg_color: res.data.goodsdetails_buy_bg_color || 'linear-gradient(90deg, #ff5041 0%, #ff695c 100%)',
            isopen_community_group_share,
            group_share_info,
            relative_goods_list: relative_goods_list_arr,
            needPosition: currentCommunity_id ? true : false
          }, () => {
            let goods_share_image = goods.goods_share_image;
            if (goods_share_image) {
              console.log('draw分享图');
              status.download(goods_share_image + "?imageView2/1/w/500/h/400").then(function(a) {
                that.goodsImg = a.tempFilePath, that.drawImgNoPrice();
              });
            } else {
              console.log('draw价格');
              let shareImg = goods.image_thumb;
              status.download(shareImg + "?imageView2/1/w/500/h/400").then(function(a) {
                that.goodsImg = a.tempFilePath, that.drawImg();
              });
            }
          })
          if (res.data.is_comunity_rest == 1) {
            wx.showModal({
              title: '温馨提示',
              content: '团长休息中，欢迎下次光临!',
              showCancel: false,
              confirmColor: '#F75451',
              confirmText: '好的',
              success(res) {}
            })
          }
          let over_type = goods.over_type;
          var seconds = 0;
          if (over_type == 0) {
            seconds = (goods.begin_time - res.data.data.cur_time) * 1000;
          } else {
            seconds = (goods.end_time - res.data.data.cur_time) * 1000;
          }
          if (seconds > 0) {
            count_down(that, seconds);
          }
          var article = res.data.data.goods.description;
          WxParse.wxParse('article', 'html', article, that, 0, app.globalData.systemInfo);
        }
      })
    }
    this.get_instructions();
    this.setData({
      canvasWidth: app.globalData.systemInfo.windowWidth,
      canvasHeight: 0.8 * app.globalData.systemInfo.windowWidth
    })
  },

  //未绑定提示
  showNoBindCommunity: function() {
    wx.showModal({
      title: '提示',
      content: '您未绑定该小区，请切换后下单！',
      showCancel: false,
      confirmColor: '#F75451',
      success(res) {
        if (res.confirm) {
          wx.redirectTo({
            url: '/lionfish_comshop/pages/position/community',
          })
        }
      }
    })
  },

  /**
   * 授权成功回调
   */
  authSuccess: function() {
    var id = this.$data.id;
    var scene = this.$data.scene;
    var community_id = this.$data.community_id;
    let url = '/lionfish_comshop/pages/goods/goodsDetail?id=' + id + '&community_id=' + community_id + '&scene=' + scene;
    app.globalData.navBackUrl = url;
    let currentCommunity = wx.getStorageSync('community');
    let needPosition = this.data.needPosition;
    if (currentCommunity) needPosition = false;
    needPosition || wx.redirectTo({
      url
    })
  },

  authModal: function() {
    if (this.data.needAuth) {
      this.setData({
        showAuthModal: !this.data.showAuthModal
      });
      return false;
    }
    return true;
  },

  /**
   * 历史社区
   */
  addhistory: function(community, isNew = false) {
    var community_id = community.communityId;
    console.log('addhistory');
    var token = wx.getStorageSync('token');
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'index.addhistory_community',
        community_id: community_id,
        'token': token
      },
      dataType: 'json',
      success: function(res) {
        if (isNew) {
          console.log('新人 社区')
          app.util.request({
            'url': 'entry/wxapp/index',
            'data': {
              controller: 'index.get_community_info',
              community_id: community_id
            },
            dataType: 'json',
            success: function(result) {
              if (result.data.code == 0) {
                let community = result.data.data;
                app.globalData.community = community;
                app.globalData.changedCommunity = true;
                wx.setStorage({
                  key: "community",
                  data: community
                })
              }
            }
          })
        }
      }
    })
  },

  /** 
   * 图片信息
   */
  imageLoad: function(e) {
    var imageSize = util.imageUtil(e)
    this.setData({
      imageSize
    })
  },

  /**
   * 获取服务信息
   */
  get_instructions: function() {
    let that = this;
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'goods.get_instructions'
      },
      dataType: 'json',
      success: function(res) {
        if (res.data.code == 0) {
          var instructions = res.data.data.value;
          WxParse.wxParse('instructions', 'html', instructions, that, 25);
          if (instructions == '') that.setData({
            noIns: true
          })
          that.setData({
            index_bottom_image: res.data.data.index_bottom_image,
            goods_details_middle_image: res.data.data.goods_details_middle_image,
            is_show_buy_record: res.data.data.is_show_buy_record,
            order_notify_switch: res.data.data.order_notify_switch,
            is_show_comment_list: res.data.data.is_show_comment_list,
            goods_details_price_bg: res.data.data.goods_details_price_bg,
            isShowContactBtn: res.data.data.index_service_switch || 0,
            goods_industrial_switch: res.data.data.goods_industrial_switch || 0,
            goods_industrial: res.data.data.goods_industrial || '',
            is_show_ziti_time: res.data.data.is_show_ziti_time || 0
          })
        }
      }
    })
  },

  /**
   * 幻灯片切换
   */
  scrollImagesChange: function(t) {
    this.videoContext.pause();
    this.setData({
      fmShow: true,
      goodsIndex: t.detail.current + 1
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    util.check_login_new().then((res) => {
      if (!res) {
        that.setData({
          needAuth: true
        })
      } else {
        (0, status.cartNum)('', true).then((res) => {
          res.code == 0 && that.setData({
            cartNum: res.data
          })
        });
      }
    })
    this.setData({
      stopNotify: false
    });
  },

  onReady: function(res) {
    this.videoContext = wx.createVideoContext('myVideo');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    this.setData({
      stopNotify: true
    })
    console.log('详情页hide', this.data.stopNotify)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    console.log('onUnload')
    this.setData({
      stopNotify: true
    })
    console.log('详情页unload', this.data.stopNotify);
    detailClearTime = null;
    clearTimeout(detailClearTime);
  },

  drawImgNoPrice: function() {
    var t = this;
    wx.createSelectorQuery().select(".canvas-img").boundingClientRect(function() {
      const context = wx.createCanvasContext("myCanvas");
      context.drawImage(t.goodsImg, 0, 0, status.getPx(375), status.getPx(300));
      if (t.data.goods.video) context.drawImage("../../images/play.png", status.getPx(150), status.getPx(105), status.getPx(76), status.getPx(76));
      context.save();
      context.restore(), context.draw(false, t.checkCanvasNoPrice());
    }).exec();
  },

  checkCanvasNoPrice: function() {
    var that = this;
    setTimeout(() => {
      wx.canvasToTempFilePath({
        canvasId: "myCanvas",
        success: function(res) {
          res.tempFilePath ? that.imageUrl = res.tempFilePath : that.drawImgNoPrice();
          console.log('我画完了')
        },
        fail: function(a) {
          that.drawImgNoPrice();
        }
      })
    }, 500)
  },

  drawImg: function() {
    let endtime = this.data.endtime;
    let shareTime = (endtime.days > 0 ? endtime.days + '天' : '') + endtime.hours + ':' + endtime.minutes + ':' + endtime.seconds;
    var t = this;
    wx.createSelectorQuery().select(".canvas-img").boundingClientRect(function() {
      const context = wx.createCanvasContext("myCanvas");
      context.font = "28px Arial";
      var e = context.measureText("￥").width + 2;
      var o = context.measureText(t.data.goods.price_front + "." + t.data.goods.price_after).width;
      context.font = "17px Arial";
      var s = context.measureText("￥" + t.data.goods.productprice).width + 3,
        n = context.measureText("累计销售 " + t.data.goods.seller_count).width,
        u = context.measureText("· 剩余" + t.data.goods.total + " ").width + 10;
      context.font = "18px Arial";
      var r = context.measureText("距结束").width;
      var d = context.measureText(shareTime).width + 10;
      context.drawImage(t.goodsImg, 0, 0, status.getPx(375), status.getPx(300));
      context.drawImage("../../images/shareBottomBg.png", status.getPx(0), status.getPx(225), status.getPx(375), status.getPx(75));
      if (t.data.goods.video) context.drawImage("../../images/play.png", status.getPx(149.5), status.getPx(74.5), status.getPx(76), status.getPx(76));
      context.save();
      status.drawText(context, {
        color: "#ffffff",
        size: 28,
        textAlign: "left"
      }, "￥", status.getPx(6), status.getPx(267), status.getPx(e));
      status.drawText(context, {
          color: "#ffffff",
          size: 28,
          textAlign: "left"
        }, t.data.goods.price_front + "." + t.data.goods.price_after,
        status.getPx(e), status.getPx(267), status.getPx(o));
      context.restore();
      context.save();
      context.restore(),
        context.save(),
        (0, status.drawText)(context, {
            color: "#ffffff",
            size: 15,
            textAlign: "left"
          },
          "￥" + t.data.goods.productprice,
          (0, status.getPx)(e + o + 10),
          (0, status.getPx)(267),
          (0, status.getPx)(s)
        ),
        context.restore(),
        context.save(),
        (0, status.drawText)(
          context, {
            color: "#ffffff",
            size: 17,
            textAlign: "left"
          },
          "累计销售" + t.data.goods.seller_count,
          (0, status.getPx)(10),
          (0, status.getPx)(290),
          (0, status.getPx)(n)
        ),
        context.restore(),
        context.save(),
        (0, status.drawText)(context, {
            color: "#ffffff",
            size: 17,
            textAlign: "left"
          },
          "· 剩余" + t.data.goods.total,
          (0, status.getPx)(n + 10),
          (0, status.getPx)(290),
          (0, status.getPx)(u)
        ),
        context.restore(),
        context.save(),
        context.beginPath(),
        context.setStrokeStyle("white"),
        context.moveTo((0, status.getPx)(e + o + 10),
          (0, status.getPx)(261)),
        context.lineTo((0, status.getPx)(e + o + s + 15),
          (0, status.getPx)(261)),
        context.stroke(),
        context.restore(),
        context.save(),
        (0, status.drawText)(context, {
            color: "#F8E71C",
            size: 18,
            textAlign: "center"
          },
          "距结束",
          (0, status.getPx)(318),
          (0, status.getPx)(260),
          (0, status.getPx)(r)
        ),
        context.restore(),
        context.save(),
        (0, status.drawText)(context, {
            color: "#F8E71C",
            size: 18,
            textAlign: "center"
          },
          shareTime,
          (0, status.getPx)(315),
          (0, status.getPx)(288),
          (0, status.getPx)(d)
        ),
        context.restore();
      context.draw(false, t.checkCanvas());
    }).exec();
  },

  checkCanvas: function() {
    var that = this;
    setTimeout(() => {
      wx.canvasToTempFilePath({
        canvasId: "myCanvas",
        success: function(res) {
          res.tempFilePath ? that.imageUrl = res.tempFilePath : that.drawImg();
          console.log('我画完了')
        },
        fail: function(a) {
          that.drawImg();
        }
      })
    }, 500)
  },

  previewImg: function(e) {
    let idx = e.currentTarget.dataset.idx || 0;
    let prevImgArr = this.data.prevImgArr;
    wx.previewImage({
      current: prevImgArr[idx],
      urls: prevImgArr
    })
  },

  /**
   * 播放视频隐藏封面图
   */
  btnPlay: function() {
    this.setData({
      fmShow: false
    })
    this.videoContext.play();
  },

  videEnd: function() {
    this.setData({
      fmShow: true
    })
  },

  endPlay: function() {
    this.videoContext.pause();
    this.setData({
      fmShow: true
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    
  }
})