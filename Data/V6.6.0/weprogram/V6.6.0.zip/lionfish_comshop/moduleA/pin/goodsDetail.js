var util = require('../../utils/util.js');
var status = require('../../utils/index.js');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_login: true,
    imageSize: {
      imageWidth: "100%",
      imageHeight: 600,
      canvasWidth: 375,
      canvasHeight: 300,
      fmShow: true
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.videoContext = wx.createVideoContext('myVideo');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 获取商品详情
   */
  getData: function () {
    let community = wx.getStorageSync('community');
    let token = wx.getStorageSync('token');
    let that = this;
    wx.showLoading();
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'goods.get_goods_detail',
        token: token,
        id: 98,
        community_id: community.communityId
      },
      dataType: 'json',
      success: function (res) {
        wx.hideLoading();
        let goods = res.data.data.goods;
        // 商品不存在
        if (!goods || goods.length == 0 || Object.keys(goods) == '') {
          wx.showModal({
            title: '提示',
            content: '该商品不存在，回首页',
            showCancel: false,
            confirmColor: '#F75451',
            success(res) {
              if (res.confirm) {
                wx.switchTab({
                  url: '/lionfish_comshop/pages/index/index',
                })
              }
            }
          })
        }
        let comment_list = res.data.comment_list;
        comment_list.map(function (item) {
          14 * item.content.length / app.globalData.systemInfo.windowWidth > 3 && (item.showOpen = true), item.isOpen = true;
        })

        // 幻灯片预览数组
        let goods_images = res.data.data.goods_image;
        let prevImgArr = [];
        goods_images.forEach(function (item) { prevImgArr.push(item.image); })

        //群分享
        let isopen_community_group_share = res.data.isopen_community_group_share || 0;
        let group_share_info = res.data.group_share_info;

        that.setData({
          order_comment_count: res.data.order_comment_count,
          comment_list: comment_list,
          goods: goods,
          options: res.data.data.options,
          order: {
            goods_id: res.data.data.goods.goods_id,
            pin_id: res.data.data.pin_id,
          },
          share_title: goods.share_title,
          buy_record_arr: res.data.data.buy_record_arr,
          goods_image: res.data.data.goods_image,
          goods_image_length: res.data.data.goods_image.length,
          service: goods.tag,
          showSkeleton: false,
          is_comunity_rest: res.data.is_comunity_rest,
          prevImgArr,
          open_man_orderbuy: res.data.open_man_orderbuy,
          man_orderbuy_money: res.data.man_orderbuy_money,
          goodsdetails_addcart_bg_color: res.data.goodsdetails_addcart_bg_color || 'linear-gradient(270deg, #f9c706 0%, #feb600 100%)',
          goodsdetails_buy_bg_color: res.data.goodsdetails_buy_bg_color || 'linear-gradient(90deg, #ff5041 0%, #ff695c 100%)',
          isopen_community_group_share,
          group_share_info
        }, () => {
          let goods_share_image = goods.goods_share_image;
          if (goods_share_image) {
            console.log('draw分享图');
            status.download(goods_share_image + "?imageView2/1/w/500/h/400").then(function (a) {
              that.goodsImg = a.tempFilePath, that.drawImgNoPrice();
            });
          } else {
            console.log('draw价格');
            let shareImg = goods.image_thumb;
            status.download(shareImg + "?imageView2/1/w/500/h/400").then(function (a) {
              that.goodsImg = a.tempFilePath, that.drawImg();
            });
          }
        })
        if (res.data.is_comunity_rest == 1) {
          wx.showModal({
            title: '温馨提示',
            content: '团长休息中，欢迎下次光临!',
            showCancel: false,
            confirmColor: '#F75451',
            confirmText: '好的',
            success(res) { }
          })
        }
        var article = res.data.data.goods.description;
        WxParse.wxParse('article', 'html', article, that, 0, app.globalData.systemInfo);
      }
    })
  },

  /** 
   * 图片信息
   */
  imageLoad: function (e) {
    var imageSize = util.imageUtil(e)
    this.setData({
      imageSize
    })
  },

  /**
   * 幻灯片滚动
   */
  scrollImagesChange: function (t) {
    this.videoContext.pause();
    this.setData({
      fmShow: true,
      goodsIndex: t.detail.current + 1
    });
  },

  /**
 * 播放视频隐藏封面图
 */
  btnPlay: function () {
    this.setData({
      fmShow: false
    })
    this.videoContext.play();
  },

  videEnd: function () {
    this.setData({
      fmShow: true
    })
  },

  endPlay: function () {
    this.videoContext.pause();
    this.setData({
      fmShow: true
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  //分享画图
  drawImgNoPrice: function () {
    var t = this;
    wx.createSelectorQuery().select(".canvas-img").boundingClientRect(function () {
      const context = wx.createCanvasContext("myCanvas");
      context.drawImage(t.goodsImg, 0, 0, status.getPx(375), status.getPx(300));
      if (t.data.goods.video) context.drawImage("../../images/play.png", status.getPx(150), status.getPx(105), status.getPx(76), status.getPx(76));
      context.save();
      context.restore(), context.draw(false, t.checkCanvasNoPrice());
    }).exec();
  },

  checkCanvasNoPrice: function () {
    var that = this;
    setTimeout(() => {
      wx.canvasToTempFilePath({
        canvasId: "myCanvas",
        success: function (res) {
          res.tempFilePath ? that.imageUrl = res.tempFilePath : that.drawImgNoPrice();
          console.log('我画完了')
        },
        fail: function (a) {
          that.drawImgNoPrice();
        }
      })
    }, 500)
  },

  drawImg: function () {
    let endtime = this.data.endtime;
    let shareTime = (endtime.days > 0 ? endtime.days + '天' : '') + endtime.hours + ':' + endtime.minutes + ':' + endtime.seconds;
    var t = this;
    wx.createSelectorQuery().select(".canvas-img").boundingClientRect(function () {
      const context = wx.createCanvasContext("myCanvas");
      context.font = "28px Arial";
      var e = context.measureText("￥").width + 2;
      var o = context.measureText(t.data.goods.price_front + "." + t.data.goods.price_after).width;
      context.font = "17px Arial";
      var s = context.measureText("￥" + t.data.goods.productprice).width + 3,
        n = context.measureText("累计销售 " + t.data.goods.seller_count).width,
        u = context.measureText("· 剩余" + t.data.goods.total + " ").width + 10;
      context.font = "18px Arial";
      var r = context.measureText("距结束").width;
      var d = context.measureText(shareTime).width + 10;
      context.drawImage(t.goodsImg, 0, 0, status.getPx(375), status.getPx(300));
      context.drawImage("../../images/shareBottomBg.png", status.getPx(0), status.getPx(225), status.getPx(375), status.getPx(75));
      if (t.data.goods.video) context.drawImage("../../images/play.png", status.getPx(149.5), status.getPx(74.5), status.getPx(76), status.getPx(76));
      context.save();
      status.drawText(context, { color: "#ffffff", size: 28, textAlign: "left" }, "￥", status.getPx(6), status.getPx(267), status.getPx(e));
      status.drawText(context, { color: "#ffffff", size: 28, textAlign: "left" }, t.data.goods.price_front + "." + t.data.goods.price_after,
        status.getPx(e), status.getPx(267), status.getPx(o));
      context.restore();
      context.save();
      context.restore(),
        context.save(),
        (0, status.drawText)(context,
          { color: "#ffffff", size: 15, textAlign: "left" },
          "￥" + t.data.goods.productprice,
          (0, status.getPx)(e + o + 10),
          (0, status.getPx)(267),
          (0, status.getPx)(s)
        ),
        context.restore(),
        context.save(),
        (0, status.drawText)(
          context,
          { color: "#ffffff", size: 17, textAlign: "left" },
          "累计销售" + t.data.goods.seller_count,
          (0, status.getPx)(10),
          (0, status.getPx)(290),
          (0, status.getPx)(n)
        ),
        context.restore(),
        context.save(),
        (0, status.drawText)(context,
          { color: "#ffffff", size: 17, textAlign: "left" },
          "· 剩余" + t.data.goods.total,
          (0, status.getPx)(n + 10),
          (0, status.getPx)(290),
          (0, status.getPx)(u)
        ),
        context.restore(),
        context.save(),
        context.beginPath(),
        context.setStrokeStyle("white"),
        context.moveTo((0, status.getPx)(e + o + 10),
          (0, status.getPx)(261)),
        context.lineTo((0, status.getPx)(e + o + s + 15),
          (0, status.getPx)(261)),
        context.stroke(),
        context.restore(),
        context.save(),
        (0, status.drawText)(context,
          { color: "#F8E71C", size: 18, textAlign: "center" },
          "距结束",
          (0, status.getPx)(318),
          (0, status.getPx)(260),
          (0, status.getPx)(r)
        ),
        context.restore(),
        context.save(),
        (0, status.drawText)(context, { color: "#F8E71C", size: 18, textAlign: "center" },
          shareTime,
          (0, status.getPx)(315),
          (0, status.getPx)(288),
          (0, status.getPx)(d)
        ),
        context.restore();
      context.draw(false, t.checkCanvas());
    }).exec();
  },

  checkCanvas: function () {
    var that = this;
    setTimeout(() => {
      wx.canvasToTempFilePath({
        canvasId: "myCanvas",
        success: function (res) {
          res.tempFilePath ? that.imageUrl = res.tempFilePath : that.drawImg();
          console.log('我画完了')
        },
        fail: function (a) {
          that.drawImg();
        }
      })
    }, 500)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})