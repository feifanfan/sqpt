var util = require('../../utils/util.js');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp()

function pintuancount_down(that, cur_time) {
  var pintuan = that.data.pintuan;
  for (var i in pintuan) {
    //end_time_html
    var total_micro_second = (pintuan[i].end_time - cur_time) * 1000;
    var second = Math.floor(total_micro_second / 1000);
    var days = second / 3600 / 24;
    var daysRound = Math.floor(days);
    var hours = second / 3600 - (24 * daysRound);
    var hoursRound = Math.floor(hours);
    var minutes = second / 60 - (24 * 60 * daysRound) - (60 * hoursRound);
    var minutesRound = Math.floor(minutes);
    var seconds = second - (24 * 3600 * daysRound) - (3600 * hoursRound) - (60 * minutesRound);
    var end_time_html = '';
    if (daysRound > 0) {
      end_time_html += daysRound + '天';
    }
    if (hoursRound > 0) {
      end_time_html += hoursRound + '时';
    }
    if (minutesRound > 0) {
      end_time_html += minutesRound + '分';
    }
    end_time_html += seconds + '秒';
    pintuan[i].end_time = pintuan[i].end_time - 1;
    pintuan[i].end_time_html = end_time_html;
  }
  that.setData({
    pintuan: pintuan
  });
  if (total_micro_second <= 0) {
    return;
  }
  setTimeout(function () {
    pintuancount_down(that, cur_time);
  }, 1000)

}

function count_down(that, total_micro_second) {
  var second = Math.floor(total_micro_second / 1000);
  var days = second / 3600 / 24;
  var daysRound = Math.floor(days);
  var hours = second / 3600 - (24 * daysRound);
  var hoursRound = Math.floor(hours);
  var minutes = second / 60 - (24 * 60 * daysRound) - (60 * hoursRound);
  var minutesRound = Math.floor(minutes);
  var seconds = second - (24 * 3600 * daysRound) - (3600 * hoursRound) - (60 * minutesRound);

  that.setData({
    endtime: {
      days: daysRound,
      hours: hoursRound,
      minutes: minutesRound,
      seconds: seconds,
      show_detail: 1
    }
  });

  if (total_micro_second <= 0) {
    that.setData({
      endtime: {
        days: "00",
        hours: "00",
        minutes: "00",
        seconds: "00",
      }
    });
    return;
  }

  setTimeout(function () {
    total_micro_second -= 1000;
    count_down(that, total_micro_second);
  }, 1000)

}
// 位数不足补零
function fill_zero_prefix(num) {
  return num < 10 ? "0" + num : num
}
Page({
  data: {
    navState: 0,
    indicatorDots: false,
    hidetip: true,
    theme_type: '',
    autoplay: true,
    interval: 5000,
    duration: 1000,
    is_login: false,
    goods: {},
    member_level_info: {},
    seller_info: {},
    options: {},
    goods_image: {},
    pin_info: {},
    showModal: false,
    skustate: 0,
    can_car: true,
    share_title: '',
    isHidenotice: true,
    jarray: [],
    sku: [],
    skudanprice: 0,
    skupin_price: 0,
    show_detail: 1,
    is_addcar: false,
    endtime: {
      days: "00",
      hours: "00",
      minutes: "00",
      seconds: "00",
    },
    order: {},
    src: '',
    video_height: 0,
    video_size_width: 0,
    vedio_size_height: 0,
    is_video: 0,
    autoplay_video: false,
    hide_video: true,
    is_share_html: true,
    service: [],
    items: [],
    inputValue: 0,
    pintuan: {}
  },
  onLoad: function (options) {
    var that = this;
    var token = wx.getStorageSync('token');
    wx.setNavigationBarTitle({
      title: '商品详情'
    });
    wx.showLoading({})
    

    wx.hideLoading();
    if (util.check_login()) {
      this.setData({
        is_login: true
      })
    }

    var scene = decodeURIComponent(options.scene)

    if (scene != 'undefined') {
      //$goods_id.'_'.$member_id
      var opt_arr = scene.split("_");
      options.id = opt_arr[0];
      wx.setStorage({
        key: "share_id",
        data: opt_arr[1]
      })
    }

    // 13
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'goods.get_goods_detail',
        'token': token,
        'id': options.id
      },
      dataType: 'json',
      success: function (res) {
        //src
        if (res.data.data.goods.is_video == 1) {
          that.videoContext = wx.createVideoContext('myVideo');
          wx.showToast({
            title: '轻触看视频',
            icon: 'none'
          })
        }
        if (res.data.data.is_show_max_level == 1) {
          console.log('会员等级--');
          var level_list = res.data.data.member_level_list;
          console.log(level_list);
          var s_items = [];
          var last_id = 0;

          for (var i in level_list) {
            var tp_g = {};
            tp_g.name = level_list[i].levelname + '  ' + level_list[i].level_money + '元/年' + ' 全场' + level_list[i].discount + '折';
            tp_g.value = level_list[i].id;
            last_id = level_list[i].id;
            if (res.data.data.member_level_info.level >= level_list[i].level) {
              tp_g.is_hide = 1;
            } else {
              tp_g.is_hide = 0;
              if (i == level_list.length - 1) tp_g.checked = "checked";
            }
            s_items.push(tp_g);
          }

          that.setData({
            items: s_items,
          })
        }

        that.setData({
          order_comment_count: res.data.order_comment_count,
          comment_list: res.data.comment_list,
          loadover: true,
          goods: res.data.data.goods,
          member_level_info: res.data.data.member_level_info,
          is_show_max_level: res.data.data.is_show_max_level,
          max_member_level: res.data.data.max_member_level,
          max_get_money: res.data.data.max_get_money,
          site_name: res.data.data.site_name,
          src: res.data.data.goods.video_src,
          is_video: res.data.data.goods.is_video,
          video_size_width: res.data.data.goods.video_size_width,
          vedio_size_height: res.data.data.goods.vedio_size_height,
          share_title: res.data.data.goods.share_title,
          options: res.data.data.options,
         
          goods_image: res.data.data.goods_image,
          pin_info: res.data.data.pin_info,
          lottery_info: res.data.data.lottery_info,
          service: res.data.data.goods.tag,
          favgoods: res.data.data.goods.favgoods,
          cur_time: res.data.data.cur_time,
          order: {
            goods_id: res.data.data.goods.goods_id,
            pin_id: res.data.data.pin_id,
          },
         
        })
        var seconds = (res.data.data.pin_info.end_time - res.data.data.cur_time) * 1000;

        if (seconds > 0) {
          count_down(that, seconds);
        }
        var article = res.data.data.goods.description;
        WxParse.wxParse('article', 'html', article, that, 0);
      }
    })

    
  /**
    wx.request({
      url: util.api() + 'index.php?s=/Apigoods/get_goods_fujin_tuan/id/' + options.id,
      success: function (res) {
        that.setData({
          pintuan: res.data.data
        })
        if (res.data.data.length > 0) {
          pintuancount_down(that, res.data.cur_time);
        }
      }
    })
     */
   // this.socketmsg();

  },
  onShow: function () {
    var that = this;
    var goods_id = this.data.order.goods_id;

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'index.wepro_index_goods',
        "per_page": 20,
        "type":'all',
        "is_index_show":2,
        "orderby": 'rand',
        "exp": goods_id,
        "page":1
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          console.log('猜你喜欢：');
          console.log(res.data.list);
          that.setData({
            showguess: false,
            guessdata: res.data.list
          });
        }
      }
    })

  },
  share_handler: function () {
    this.setData({
      is_share_html: false
    })
  },
  hide_share_handler: function () {
    this.setData({
      is_share_html: true
    })
  },
  share_quan: function () {
    wx.showLoading({
      title: '获取中',
    })
    var token = wx.getStorageSync('token');
    var goods_id = this.data.order.goods_id;
    var that = this;

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'goods.get_user_goods_qrcode',
        "token": token,
        "goods_id": goods_id
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          setTimeout(function () {
            wx.hideLoading()
          }, 2000)
          var image_path = res.data.image_path;
          wx.getImageInfo({
            src: image_path,
            success: function (res) {
              var real_path = res.path;
              wx.saveImageToPhotosAlbum({
                filePath: real_path,
                success(res) {
                  wx.showToast({
                    title: '图片保存成功，可以分享了',
                    icon: 'none',
                    duration: 2000
                  })
                  that.setData({
                    is_share_html: true
                  });
                }
              })
            }
          })
        }
      }
    })

    

  },
  goPlayVideo: function (e) {
    console.log('play video');

    var that = this;

    //获取屏幕宽高  
    wx.getSystemInfo({
      success: function (res) {
        var windowWidth = res.windowWidth;
        windowWidth = windowWidth * 0.7;
        var windowHeight = res.windowHeight;
        var windowscale = windowHeight / windowWidth; //屏幕高宽比  
        console.log('windowWidth: ' + windowWidth)
        console.log('windowHeight: ' + windowHeight)

        var direction = 0;
        if (that.data.vedio_size_height > that.data.video_size_width) {
          direction = -90;
        }
        console.log(direction);
        var need_height = (windowWidth * that.data.vedio_size_height) / that.data.video_size_width;
        if (need_height > windowHeight) {
          need_height = windowHeight - 8;
        }
        that.setData({
          video_height: need_height,
          hide_video: false,
          direction: direction
        })
        that.videoContext.play();
        that.videoContext.requestFullScreen();
      }
    })
  },
  imageLoad: function (e) {
    var imageSize = util.imageUtil(e)
    this.setData({
      imagewidth: imageSize.imageWidth,
      imageheight: imageSize.imageHeight
    })
  },
  close_video: function () {
    var that = this;
    that.videoContext.pause();
    that.setData({
      hide_video: true
    })

  },
  goOrderfrom: function (e) {
    var from_id = e.detail.formId;
    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/user',
      'data': {
        controller: 'user.get_member_form_id',
        'token': token,
        "from_id": from_id
      },
      dataType: 'json',
      success: function (res) {
      }
    })
    
    this.goOrder();
  },
  goGoods: function (event) {
    let id = event.currentTarget.dataset.type;

    var pages_all = getCurrentPages();
    if (pages_all.length > 3) {
      wx.redirectTo({
        url: '/pages/goods/index?id=' + id
      })
    } else {
      wx.navigateTo({
        url: '/pages/goods/index?id=' + id
      })
    }

  },
  socketmsg: function () {
    wx.closeSocket();

    var domain = util.getdomain();
    var self = this;
    wx.connectSocket({
      url: 'wss://mall.shiziyu888.com/wss',
      header: {
        'content-type': 'application/json'
      },
      method: "GET"
    })
    wx.onSocketOpen(function (res) {


      var login_data = '{ "type":"membre_login","domain":"' + domain + '"} ';
      wx.sendSocketMessage({
        data: login_data
      });

      setTimeout(function () {
        var ck_lo_pt = util.api() + "/index.php?s=/Apigoods/notify_order/rt/28163.html";
        wx.request({
          url: ck_lo_pt,
          type: 'get',
          dataType: 'json',
          success: function (res) {
            if (res.data.ret == 1) {
              self.send_bao_notify(res.data);
            }
          }
        })
      }, 1000);
      setInterval(function () {

        if (self.data.jarray.length > 0) {
          var res = self.data.jarray.pop();

          self.show_or(res);
        }
      }, 4000);

    })

    wx.onSocketMessage(function (res) {

      var data = util.stringToJson(res.data);
      console.log(data);
      switch (data.type) {
        // 服务端ping客户端
        case 'ping':
          var pong_data = '{"type":"pong"}';
          wx.sendSocketMessage({
            data: pong_data
          });
          break;
        case 'member_buy_msg':

          var jarray_str = self.data.jarray;
          jarray_str.push(data);
          self.setData({
            jarray: jarray_str
          });
          //this.on_member_buy_msg(data);
          break;
      }


    })
    wx.onSocketError(function (res) {
      console.log('WebSocket连接打开失败，请检查！')
    })
  },
  send_bao_notify: function (res) {
    var buy_data = '{ "type":"member_buy","avatar":"' + res.avatar + '","miao":"' + res.miao + '","username":"' + res.username + '","order_id":"' + res.order_id + '","order_url":"' + res.order_url + '"} ';
    wx.sendSocketMessage({
      data: buy_data
    });
  },
  show_or: function (res) {
    this.setData({
      notice_orderid: res.order_id,
      notice_avatar: res.avatar,
      notice_name: res.username,
      notice_miao: res.miao,
      isHidenotice: false
    });

    var self = this;
    setTimeout(function () {
      self.setData({
        isHidenotice: true
      })

      setTimeout(function () {
        if (self.data.jarray.length > 0) {
          var res = self.data.jarray.pop();
          self.show_or(res);
        }
      }, 3000);
    }, 2000);
  },
  ck_tab: function (e) {
    var rel = e.currentTarget.dataset.rel;
    this.setData({
      show_detail: rel
    })

  },
  goRewardList: function () {
    var goods_id = this.data.order.goods_id;

    var pages_all = getCurrentPages();
    if (pages_all.length > 3) {
      wx.redirectTo({
        url: '/pages/goods/lotteryinfo?id=' + goods_id
      })
    } else {
      wx.navigateTo({
        url: '/pages/goods/lotteryinfo?id=' + goods_id
      })
    }
  },
  noticego: function (e) {
    var orderid = e.currentTarget.dataset.orderid;

    var pages_all = getCurrentPages();
    if (pages_all.length > 3) {
      wx.redirectTo({
        url: '/pages/share/index?id=' + orderid
      })
    } else {
      wx.navigateTo({
        url: '/pages/share/index?id=' + orderid
      })
    }

  },
  navShow: function () {
    this.setData({
      navState: 1
    })
  },
  navHide: function () {
    this.setData({
      navState: 0
    })
  },
  bindGetUserInfo: function (e) {
    var id = this.data.goods.goods_id;
    util.login('/Snailfish_shop/pages/goods/index?id=' + id);
    this.setData({
      is_login: true
    })
  },
  goBuy: function (event) {
    var that = this;
    var buy_type = event.currentTarget.dataset.type;
    var is_car = event.currentTarget.dataset.is_car;

    if (is_car == undefined) {

      this.setData({
        is_addcar: false
      })
    } else {
      this.setData({
        is_addcar: true
      })
    }

    var order = that.data.order;
    order.buy_type = buy_type;
    order.quantity = 1;
    var skudanprice = this.data.skudanprice;
    var skupin_price = this.data.skupin_price;
    

    //goods.danprice:pin_info.pin_price
    //order.buy_type=='dan'?goods.danprice:pin_info.pin_price

    if (order.buy_type == 'dan') {
      skudanprice = this.data.goods.danprice;
    } 
    else {
      skupin_price = this.data.pin_info.pin_price;
    }
    //skudanprice:skupin_price

    this.setData({
      order: order,
      skudanprice: skudanprice,
      skupin_price: skupin_price
    })

    if (that.data.options.list.length > 0) {
      let list = that.data.options.list;
      let arr = [];
      for (let i = 0; i < list.length; i++) {
        let sku = list[i]['option_value'][0];
        let temp = {
          name: sku['name'],
          id: sku['option_value_id'],
          index: i,
          idx: 0
        };
        arr.push(temp);
      }
      //把单价剔除出来begin

      var id = '';
      for (let i = 0; i < arr.length; i++) {
        if (i == arr.length - 1) {
          id = id + arr[i]['id'];
        } else {
          id = id + arr[i]['id'] + "_";
        }
      }
      var that = this;
      var token = wx.getStorageSync('token');

      app.util.request({
        'url': 'entry/wxapp/index',
        'data': {
          controller: 'goods.get_goods_option_data',
          'id': that.data.goods.goods_id,
          'sku_str': id,
          'token': token
        },
        dataType: 'json',
        success: function (res) {

          var goods = that.data.goods;
          goods.quantity = res.data.data.value.quantity;
          goods.image = res.data.data.value.image;
          goods.danprice = res.data.data.value.dan_price;
          goods.memberprice = res.data.data.value.memberprice;

          that.setData({
            goods: goods,
            max_get_money: res.data.data.value.max_member_pin_price,
            skudanprice: goods.danprice
          })
          var pin_info = that.data.pin_info;
          pin_info.pin_price = res.data.data.value.pin_price;
          pin_info.member_pin_price = res.data.data.value.member_pin_price;

          that.setData({
            pin_info: pin_info,
            skupin_price: pin_info.pin_price
          })

        }
      })


      //end
      that.setData({
        sku: arr,
        skustate: 1
      })
    } else {
      that.goOrder();
    }
  },
  closeSku: function () {
    this.setData({
      skustate: 0
    })

  },
  goOrder: function () {

    var token = wx.getStorageSync('token');
    var that = this;
    if (that.data.can_car) {
      that.data.can_car = false;
    }
    var is_just_addcar = 0;
    if (that.data.is_addcar) {
      is_just_addcar = 1;
    }

    if (that.data.options.list.length > 0) {
      var id = '';
      let arr = that.data.sku;
      for (let i = 0; i < arr.length; i++) {
        if (i == arr.length - 1) {
          id = id + arr[i]['id'];
        } else {
          id = id + arr[i]['id'] + "_";
        }
      }
      var order = that.data.order;
      order.sku_str = id;
      that.setData({
        order: order
      })
    }

    app.util.request({
      'url': 'entry/wxapp/user',
      'data': {
        controller: 'car.add',
        'token': token,
        "goods_id": that.data.order.goods_id,
        "quantity": that.data.order.quantity,
        "sku_str": that.data.order.sku_str,
        "buy_type": that.data.order.buy_type,
        "pin_id": that.data.order.pin_id,
        "is_just_addcar": is_just_addcar
      },
      dataType: 'json',
      method: 'POST',
      success: function (res) {
        //console.log(res);
        if (res.data.code == 3) {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000
          })
        } else if (res.data.code == 4) {

          var id = that.data.goods.goods_id;
          wx.showToast({
            title: '您未登录',
            icon: 'loading',
            duration: 2000,
            complete:function(){
              wx.setStorage({
                key: "member_id",
                data: null
              })
              wx.redirectTo({
                url: '/Snailfish_shop/pages/goods/index?id=' + id
              })
            }
          })

         
        } else if (res.data.code == 6) {
          var msg = res.data.msg;
          wx.showToast({
            title: msg,
            icon: 'none',
            duration: 2000
          })
        } else {

          if (is_just_addcar == 1) {
            that.closeSku();
            wx.showToast({
              title: '加入购物车成功',
              duration: 2000
            })
          } else {
            var pages_all = getCurrentPages();
            if (pages_all.length > 3) {
              wx.redirectTo({
                url: '/Snailfish_shop/pages/buy/index?type=' + that.data.order.buy_type
              })
            } else {
              wx.navigateTo({
                url: '/Snailfish_shop/pages/buy/index?type=' + that.data.order.buy_type
              })
            }
          }

        }

      }
    })

    

  },
  setNum: function (event) {
    let types = event.currentTarget.dataset.type;
    var num = 1;
    if (types == 'add') {
      num = this.data.order.quantity + 1;
    } else if (types == 'decrease') {
      if (this.data.order.quantity > 1) {
        num = this.data.order.quantity - 1;
      }
    }
    var order = this.data.order;
    order.quantity = num;
    this.setData({
      order: order
    })
  },
  goShare: function (event) {
    let id = event.currentTarget.dataset.type;
    var pages_all = getCurrentPages();

    if (pages_all.length > 3) {
      wx.redirectTo({
        url: '/pages/share/index?id=' + id
      })
    } else {
      wx.navigateTo({
        url: '/pages/share/index?id=' + id
      })
    }

  },
  goLink_direct: function (event) {
    let link = event.currentTarget.dataset.link;

    var pages_all = getCurrentPages();

    wx.reLaunch({
      url: link
    })
  },
  goLink: function (event) {
    let link = event.currentTarget.dataset.link;

    var pages_all = getCurrentPages();

    wx.reLaunch({
      url: link
    })
  },
  go_goods_comment: function () {
    var goods = this.data.goods;
    var pages_all = getCurrentPages();
    if (pages_all.length > 3) {
      wx.redirectTo({
        url: '/Snailfish_shop/pages/goods/comment?id=' + goods.goods_id
      })
    } else {
      wx.navigateTo({
        url: '/Snailfish_shop/pages/goods/comment?id=' + goods.goods_id
      })
    }

  },
  gokefu: function () {

    //跳入客服

  },
  goStore: function (event) {
    let id = event.currentTarget.dataset.type;

    var pages_all = getCurrentPages();
    if (pages_all.length > 3) {
      wx.redirectTo({
        url: '/pages/store/index?id=' + id
      })
    } else {
      wx.navigateTo({
        url: '/pages/store/index?id=' + id
      })
    }

  },
  openSku: function (event) {

    var that = this;
    var buy_type = event.currentTarget.dataset.type;
    var order = that.data.order;
    order.buy_type = buy_type;
    order.quantity = 1;
    var skudanprice = this.data.skudanprice;
    var skupin_price = this.data.skupin_price;

    if (order.buy_type == 'dan') {
      skudanprice = this.data.goods.danprice;
    } else {
      skupin_price = this.data.pin_info.pin_price;
    }
    //skudanprice:skupin_price

    this.setData({
      order: order,
      skudanprice: skudanprice,
      skupin_price: skupin_price
    })

    if (that.data.options.list.length > 0) {
      let list = that.data.options.list;
      let arr = [];
      for (let i = 0; i < list.length; i++) {
        let sku = list[i]['option_value'][0];
        let temp = {
          name: sku['name'],
          id: sku['option_value_id'],
          index: i,
          idx: 0
        };
        arr.push(temp);
      }
      //把单价剔除出来begin

      var id = '';
      for (let i = 0; i < arr.length; i++) {
        if (i == arr.length - 1) {
          id = id + arr[i]['id'];
        } else {
          id = id + arr[i]['id'] + "_";
        }
      }
      var that = this;
      var token = wx.getStorageSync('token');

      app.util.request({
        'url': 'entry/wxapp/index',
        'data': {
          controller: 'goods.get_goods_option_data',
          'id': that.data.goods.goods_id,
          'sku_str': id,
          'token': token
        },
        dataType: 'json',
        success: function (res) {

          var goods = that.data.goods;
          goods.quantity = res.data.data.value.quantity;
          goods.image = res.data.data.value.image;
          goods.danprice = res.data.data.value.dan_price;
          goods.memberprice = res.data.data.value.memberprice;

          that.setData({
            goods: goods,
            max_get_money: res.data.data.value.max_member_pin_price,
            skudanprice: goods.danprice
          })
          var pin_info = that.data.pin_info;
          pin_info.pin_price = res.data.data.value.pin_price;
          pin_info.member_pin_price = res.data.data.value.member_pin_price;
          that.setData({
            pin_info: pin_info,
            skupin_price: pin_info.pin_price
          })
        }
      })

      //end
      that.setData({
        sku: arr,
        skustate: 1
      })
    } else {
      that.goOrder();
    }
  },
  selectSku: function (event) {
    var that = this;
    let str = event.currentTarget.dataset.type;
    let obj = str.split("_");
    let arr = that.data.sku;
    let temp = {
      name: obj[3],
      id: obj[2],
      index: obj[0],
      idx: obj[1]
    };
    arr.splice(obj[0], 1, temp);
    that.setData({
      sku: arr
    })
    var id = '';
    for (let i = 0; i < arr.length; i++) {
      if (i == arr.length - 1) {
        id = id + arr[i]['id'];
      } else {
        id = id + arr[i]['id'] + "_";
      }
    }
    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'goods.get_goods_option_data',
        'id': that.data.goods.goods_id,
        'sku_str': id,
        'token': token
      },
      dataType: 'json',
      success: function (res) {

        var goods = that.data.goods;
        goods.quantity = res.data.data.value.quantity;
        goods.image_thumb = res.data.data.value.image;
        goods.danprice = res.data.data.value.dan_price;
        goods.memberprice = res.data.data.value.memberprice;


        that.setData({
          goods: goods,
          max_get_money: res.data.data.value.max_member_pin_price,
          skudanprice: goods.danprice
        })
        var pin_info = that.data.pin_info;
        pin_info.pin_price = res.data.data.value.pin_price;
        pin_info.member_pin_price = res.data.data.value.member_pin_price;

        that.setData({
          pin_info: pin_info,
          skupin_price: pin_info.pin_price
        })
      }
    })

    
  },
  radioChange: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  showDialogBtn: function () {
    this.setData({
      showModal: true
    })
  },
  charge_form: function () {
    this.setData({
      showModal: true
    })
  },
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  onCancel: function () {
    this.hideModal();
  },
  onConfirm: function () {
    if (this.data.member_level_info.level_id == this.data.inputValue) {
      this.hideModal();
      return false;
    }

    var money = parseFloat(this.data.inputValue);
    if (money <= 0) {
      wx.showToast({
        title: '请选择升级等级',
        icon: 'none',
        duration: 2000
      })

    } else {
      this.hideModal();
      var that = this;
      var token = wx.getStorageSync('token');

      wx.request({
        url: util.api() + 'index.php?s=/Apicheckout/wxcharge/token/' + token + '/money/' + money,
        success: function (res) {
          wx.requestPayment({
            "appId": res.data.appId,
            "timeStamp": res.data.timeStamp,
            "nonceStr": res.data.nonceStr,
            "package": res.data.package,
            "signType": res.data.signType,
            "paySign": res.data.paySign,
            'success': function (wxres) {
              wx.showToast({
                title: '升级成功',
              })
              setTimeout(() => {
                var share_path = '/pages/goods/index?id=' + that.data.goods.goods_id + '&charge_suc=1';
                wx.redirectTo({
                  url: share_path
                })
              }, 2000)
            },
            'fail': function (res) {
              console.log(res);
            }
          })
        }
      })

    }

  },
  favtoggle: function () {
    let that = this;
    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/user',
      'data': {
        controller: 'user.fav_toggle',
        'token': token,
        goods_id: that.data.goods.goods_id
      },
      dataType: 'json',
      success: function (res) {
        that.setData({
          favgoods: res.data.code
        })
      }
    })

    wx.request({
      url: util.api() + 'index.php?s=/Apiuser/fav_toggle/goods_id/' + that.data.goods.goods_id + '/token/' + token,
      success: function (res) {
        that.setData({
          favgoods: res.data.code
        })

      }
    })
  },
  onShareAppMessage: function (res) {
    var share_title = this.data.share_title;

    var share_id = wx.getStorageSync('member_id');

    var share_path = 'pages/goods/index?id=' + this.data.goods.goods_id + '&share_id=' + share_id;

    var that = this;
    return {
      title: share_title,
      path: share_path,
      success: function (res) {
        // 转发成功
        that.setData({
          is_share_html: true
        })
      },
      fail: function (res) {
        // 转发失败
        that.setData({
          is_share_html: true
        })
      }
    }
  }
})