// pages/dan/address_list.js
var util = require('../../utils/util.js');
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    region: ['省', '市', '区'],
    show_add_address: false,
    is_direct: 0,
    buy_type: '',
    sub_address_id: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '收货地址'
    });
    //is_direct=1&buy_type=
    var is_direct = options.is_direct;

    if (is_direct != undefined) {
      var s_buy_type = options.buy_type;

      this.setData({
        is_direct: 1,
        buy_type: s_buy_type
      })
    }
    this.get_data();
  },
  go_order_buy: function (event) {
    let id = event.currentTarget.dataset.id;

    var that = this;

    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'user.set_default_address',
        token: token,
        id: id
      },
      dataType: 'json',
      success: function (res) {
        let url = "/Snailfish_shop/pages/buy/index?type=" + that.data.buy_type;

        var pages_all = getCurrentPages();
        if (pages_all.length > 3) {
          wx.redirectTo({
            url: url
          })
        } else {
          wx.navigateTo({
            url: url
          })
        }

      }
    })


    
  },
  get_data: function () {
    var that = this;
    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'user.getaddress',
        token: token
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          that.setData({
            list: res.data.list
          })
        } else {
          that.setData({
            list: []
          })
        }
      }
    })
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  edit_address: function (event) {
    let id = event.currentTarget.dataset.id;
    var that = this;
    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': { 
        controller: 'user.get_address_info',
        token: token,
        id: id
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          that.setData({
            addr_name: res.data.info.name,
            addr_tel: res.data.info.telephone,
            region: [res.data.info.province_name, res.data.info.city_name, res.data.info.country_name],
            addr_detail: res.data.info.address,
            sub_address_id: res.data.info.address_id
          })
          that.show_add_selfaddress();
        }
      }
    })
  },
  del_adderess: function (event) {
    let id = event.currentTarget.dataset.id;
    var that = this;
    var token = wx.getStorageSync('token');
    wx.showModal({
      title: '提示',
      content: '确认删除地址吗？',
      success: function (res) {
        if (res.confirm) {
          app.util.request({
            'url': 'entry/wxapp/index',
            'data': { 
              controller: 'user.del_address',
              token: token,
              id: id
              },
            dataType: 'json',
            success: function (res) {
              that.get_data();
            }
          })
        } else if (res.cancel) {

        }
      }
    })

  },
  set_default: function (event) {

    let id = event.currentTarget.dataset.id;
    var that = this;

    var token = wx.getStorageSync('token');

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'user.set_default_address',
        token: token,
        id: id
      },
      dataType: 'json',
      success: function (res) {
        that.get_data();
      }
    })


  },
  load_wx_add: function () {
    var that = this;

    wx.chooseAddress({
      success: function (res) {
        var token = wx.getStorageSync('token');
        res.controller = 'user.add_weixinaddress';
        res.token = token;
        

        app.util.request({
          'url': 'entry/wxapp/index',
          'data': res,
          method:'post',
          dataType: 'json',
          success: function (msg) {
            that.get_data();
          }
        })
        

      }
    })
  },
  chooseAddress: function () {

    var that = this;
    wx.getSetting({
      success: function (res) {
        var add_scope = res.authSetting;
        that.load_wx_add();
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  bindAddrdetailInput: function (e) {
    this.setData({
      addr_detail: e.detail.value
    })
  },
  bindAddrtelInput: function (e) {
    this.setData({
      addr_tel: e.detail.value
    })
  },
  bindAddrnameInput: function (e) {
    this.setData({
      addr_name: e.detail.value
    })
  },
  bindMobileInput: function (e) {
    this.setData({
      ziti_mobile: e.detail.value
    })
  },
  bindRegionChange: function (e) {
     /** 
    this.setData({
      region: e.detail.value
    })
    **/
  },
  show_add_selfaddress_clear: function () {
    this.setData({
      addr_name: '',
      addr_tel: '',
      region: ['省', '市', '区'],
      addr_detail: '',
      sub_address_id: 0,
      show_add_address: true
    })

  },
  show_add_selfaddress: function () {

    this.setData({
      show_add_address: true
    })
  },
  close_address_dialog: function () {
    this.setData({
      show_add_address: false
    })
  },
  chose_location: function () {
    var that = this;
    wx.chooseLocation({
      success: function (e) {

        var path = e.address;
        var s_region = that.data.region;
        var dol_path = '';


        var str = path;
        var patt = new RegExp("(.*?省)(.*?市)(.*?区)", "g");
        var result = patt.exec(str);
        if (result == null) {
          patt = new RegExp("(.*?省)(.*?市)(.*?市)", "g");
          result = patt.exec(str);
          if (result == null) {
            patt = new RegExp("(.*?省)(.*?市)(.*县)", "g");
            result = patt.exec(str);
            if (result == null) {
            } else {
              if (s_region[0] != result[1] || s_region[1] != result[2] || s_region[2] != result[3]) {
                wx.showToast({
                  title: '省市区信息已同步修改',
                  icon: 'none',
                })
              }
              s_region[0] = result[1];
              s_region[1] = result[2];
              s_region[2] = result[3];
              dol_path = path.replace(result[0], '');

            }
          } else {
            if (s_region[0] != result[1] || s_region[1] != result[2] || s_region[2] != result[3]) {
              wx.showToast({
                title: '省市区信息已同步修改',
                icon: 'none',
              })
            }
            s_region[0] = result[1];
            s_region[1] = result[2];
            s_region[2] = result[3];
            dol_path = path.replace(result[0], '');
          }
        } else {
          if (s_region[0] != result[1] || s_region[1] != result[2] || s_region[2] != result[3]) {
            wx.showToast({
              title: '省市区信息已同步修改',
              icon: 'none',
            })
          }
          s_region[0] = result[1];
          s_region[1] = result[2];
          s_region[2] = result[3];

          dol_path = path.replace(result[0], '');
        }
        if (s_region[0] == '省') {
          wx.showToast({
            title: '请重新选择省市区',
            icon: 'none',
          })
        }
        var filename = dol_path + e.name;

        that.setData({
          region: s_region,
          addr_detail: filename
        })
      }
    })
  },
  sub_address_do: function () {

    var token = wx.getStorageSync('token');
    var addr_name = this.data.addr_name;
    var addr_tel = this.data.addr_tel;
    var province_name = this.data.region[0];
    var city_name = this.data.region[1];
    var area_name = this.data.region[2];
    var addr_detail = this.data.addr_detail;
    var that = this;

    if (addr_name == '') {
      wx.showToast({
        title: '请填写姓名',
      })
      return false;
    }
    if (addr_tel == '') {
      wx.showToast({
        title: '请填写电话',
      })
      return false;
    }

    if (province_name == '省' && city_name == '市' && area_name == '区') {
      wx.showToast({
        title: '请选择地区',
      })
      return false;
    }

    if (addr_detail == '') {
      wx.showToast({
        title: '请填写详细地址',
      })
      return false;
    }

    var res = { province_name: province_name, city_name: city_name, area_name: area_name, addr_tel: addr_tel, addr_detail: addr_detail, addr_name: addr_name, sub_address_id: that.data.sub_address_id, controller: 'user.add_weixin_selftaddress',
      token: token 
    };

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': res,
      method: 'POST',
      dataType: 'json',
      success: function (msg) {
        that.setData({
          show_add_address: false
        })
        that.get_data();
      }
    })



  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})