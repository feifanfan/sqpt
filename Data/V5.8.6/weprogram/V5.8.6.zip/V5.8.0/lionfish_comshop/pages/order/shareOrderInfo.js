var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    order: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let order_id = options.order_id || 0;
    if (order_id == undefined || !order_id){
      wx.redirectTo({
        url: '/lionfish_comshop/pages/index/index',
      })
    }
    wx.showLoading();
    this.getData(order_id);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 获取数据
   */
  getData: function (order_id) {
    let that = this;
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'order.order_head_info',
        id: order_id,
        is_share: 1
      },
      dataType: 'json',
      method: 'POST',
      success: function (res) {
        wx.hideLoading();
        if(res.data.code == 0){
          that.setData({
            order: res.data.data
          })
        }
      }
    })
  },

  /**
   * 去商品详情
   */
  goGoodsDetails: function(e){
    let id = e.currentTarget.dataset.id || 0;
    wx.navigateTo({
      url: '/lionfish_comshop/pages/goods/goodsDetail?id=' + id,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  }
})