var e = require("../../utils/timeFormat");

Component({
  properties: {
    spuItem: {
      type: Object,
      value: {
        spuId: "",
        skuId: "",
        spuImage: "",
        spuName: "",
        endTime: "",
        beginTime: "",
        actPrice: ["", ""],
        marketPrice: ["", ""],
        spuCanBuyNum: "",
        soldNum: "",
        actId: "",
        limitMemberNum: "",
        limitOrderNum: "",
        serverTime: "",
        isLimit: !1,
        skuList: [],
        spuDescribe: "",
        promotionDTO: {}
      },
      observer: function (i) {
        if (i) {
          var t = (0, e.getBeginTime)(i.beginTime, i.serverTime);
          this.setData({
            formatBeginTime: t
          });
        }
      }
    },
    isPast: {
      type: Boolean,
      value: false
    }
  },
  data: {
    disabled: false,
    formatBeginTime: ""
  },
  methods: {
    openSku: function () {
      this.triggerEvent("openSku", {
        skuList: this.data.spuItem.skuList,
        promotionDTO: this.data.spuItem.promotionDTO
      });
    }
  }
});