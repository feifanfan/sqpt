var t = require("../../utils/timeFormat"),
  e = getApp();

Component({
  properties: {
    target: {
      type: String
    },
    showDay: Boolean,
    beginTime: String,
    callback: String,
    format: Array,
    clearTimer: Boolean
  },
  externalClasses: ["countdown-class", "item-class"],
  data: {
    time: {
      day: "0",
      second: "00",
      minute: "00",
      hour: "00"
    },
    resultFormat: [],
    changeFormat: !1,
    timeStamp: 0,
    timer: null
  },
  ready: function() {
    this.init(this.data.target);
  },
  methods: {
    init: function(t) {
      var a = this,
        i = {
          day: "0",
          second: "00",
          minute: "00",
          hour: "00"
        };
      if (t - new Date().getTime() <= 0) return this.setData({
        time: i
      }), void this.triggerEvent("callback");
      this.data.timer = e.globalData.timer.add(function() {
        a.interval(t);
      });
    },
    interval: function(a) {
      var i = a - new Date().getTime();
      if (i <= 0) return e.globalData.timer.remove(this.data.timer), this.triggerEvent("callback"),
        void this.setData({
          time: {
            day: "0",
            second: "00",
            minute: "00",
            hour: "00"
          }
        });
      var r = Math.ceil(i / 1e3),
        n = parseInt(r / 86400),
        o = r % 86400,
        m = (0, t.formatNumber)(parseInt(o / 3600));
      o %= 3600;
      var s = {
        day: n,
        hour: m,
        minute: (0, t.formatNumber)(parseInt(o / 60)),
        second: (0, t.formatNumber)(o % 60)
      };
      this.setData({
        time: s
      });
    }
  },
  detached: function() {
    e.globalData.timer.remove(this.data.timer);
  }
});