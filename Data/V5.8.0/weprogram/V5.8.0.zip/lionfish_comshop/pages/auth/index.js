// lionfish_comshop/pages/auth/index.js
var util = require('../../utils/util.js');
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    canIUse: wx.canIUse("button.open-type.getUserInfo"),
    backurl: "/lionfish_comshop/pages/index/index",
    navType: 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let url = options.url;
    let navType = options.t || 0;
    let modify_item = options.modify_item || 0;
    let id = options.id || 0;
    console.log(options)
    if (typeof (url) != "undefined" && url){
      this.setData({ 
        backurl: url,
        navType: navType,
        modify_item: modify_item,
        id: id
      })
    }
  },

  bindGetUserInfo: function (e) {
    let that = this;
    let url = "";
    if (this.data.modify_item)
    {
      url = that.data.backurl + '?' + this.data.modify_item +'=' + this.data.id
    }
    else if (this.data.id){
      url = that.data.backurl + '?id=' + this.data.id
    } else {
      url = that.data.backurl
    }
    console.log(url)

    util.login(url, that.data.navType);
  }
})