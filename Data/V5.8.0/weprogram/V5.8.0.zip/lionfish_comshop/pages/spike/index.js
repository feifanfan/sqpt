// Snailfish_shop/pages/spike/index.js
var util = require('../../utils/util.js');
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    endTime: '2018-11-30 14:56:11',
    countDown: {
      day: '00',
      hou: '00',
      min: '00',
      sec: '00'
    },
    nav_list:[],
    loadover: false,
    no_order: 0,
    cur_key:'',
    cur_type:'',
    goods: [],
    page: 1,
    isHideLoadMore: true,
    showTpo: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var that = this;

    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'index.spike_index'
      },
      dataType: 'json',
      success: function (res) {
        if(res.data.code == 0)
        {
          var cur_tab = res.data.data[0];
          that.setData({
            cur_type:cur_tab.type,
            cur_key: cur_tab.key,
            endTime: cur_tab.end_time,
            nav_list:res.data.data
          })
          that.countDown();
          that.getData();
        }
      }
    })

    //this.countDown();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  goLink2: function (e) {
    var cur_type = this.data.cur_type;
    if(cur_type =='wait')
    {

      return false;
    }  
    var link = e.currentTarget.dataset.link;
    var pages_all = getCurrentPages();
    if (pages_all.length > 3) {
      wx.redirectTo({
        url: link
      })
    } else {
      wx.navigateTo({
        url: link
      })
    }

  },
  getData: function () {
    this.setData({
      isHideLoadMore: true
    })

    this.data.no_order = 1
    var page = this.data.page;
    var cur_key = this.data.cur_key;

    var self = this;
    app.util.request({
      'url': 'entry/wxapp/index',
      'data': {
        controller: 'index.load_spike_data',
        'cur_key': cur_key,
        page: page
      },
      dataType: 'json',
      success: function (data) {
        console.log(data);

        if (data.data.code == 0) {
          var agoData = self.data.goods;
          var goods = data.data.data;

          goods.map(function (good) {
            agoData.push(good);
          });
          self.setData({
            goods: agoData,
            'no_order': 0
          });

        } else {
          self.setData({
            isHideLoadMore: true,
            showTpo: false
          })
          return false;
        }

      }
    })

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 切换Tab
   */
  changeTab: function (e) {
    let idx = e.currentTarget.dataset.index || 0;
    console.log(idx);
    //data-key='{{item.key}}' data-index="{{index}}" data-type="{{item.type}}"
    var cur_key = e.currentTarget.dataset.key;
    var cur_type = e.currentTarget.dataset.type;
 
    this.setData({
      currentTab: idx,
      cur_key: cur_key,
      goods: [],
      isHideLoadMore:true,
      showTpo:true,
      page: 1,
      cur_type: cur_type
    })
    this.getData();
  },

  //小于10的格式化函数
  timeFormat: function (param) {
    return param < 10 ? '0' + param : param;
  },

  //倒计时函数
  countDown: function () {
    let newTime = new Date().getTime();
    let o = this.data.endTime;
    let endTime = new Date(o).getTime();
    let obj = null;
    // 如果活动未结束，对时间进行处理
    if (endTime - newTime > 0) {
      let time = (endTime - newTime) / 1000;
      // 获取天、时、分、秒
      let day = parseInt(time / (60 * 60 * 24));
      let hou = parseInt(time % (60 * 60 * 24) / 3600);
      let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
      let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
      obj = {
        day: this.timeFormat(day),
        hou: this.timeFormat(hou),
        min: this.timeFormat(min),
        sec: this.timeFormat(sec)
      }
    } else {//活动已结束，全部设置为'00'
      obj = {
        day: '00',
        hou: '00',
        min: '00',
        sec: '00'
      }
    }
    // 渲染，然后每隔一秒执行一次倒计时函数
    this.setData({ countDown: obj })
    setTimeout(this.countDown, 1000);
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.no_order == 1) return false;
    this.data.page += 1;
    this.getData();

    this.setData({
      isHideLoadMore: false
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})