var siteinfo = { "siteroot": "https://sqtg.shiziyu888.com/wxapp.php"}
module.exports = siteinfo