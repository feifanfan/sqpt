var app = getApp();
// var WxParse = require('../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    member_info: {}
  },

  getData: function(){
    wx.showLoading();
    var token = wx.getStorageSync('token');
    let that = this;
    app.util.request({
      'url': 'entry/wxapp/user',
      'data': {
        controller: 'vipcard.get_vipcard_baseinfo',
        token: token
      },
      dataType: 'json',
      success: function (res) {
        wx.hideLoading();
        if (res.data.code == 0) {
          let { 
            member_info, 
            card_equity_list, 
            card_list, 
            is_open_vipcard_buy,
            modify_vipcard_name,
            is_vip_card_member,
            vipcard_unopen_headbg,
            vipcard_effect_headbg,
            vipcard_afterefect_headbg,
            vipcard_buy_pagenotice,
            vipcard_equity_notice,
            // del_vip_day
          } = res.data.data;
          // WxParse.wxParse('article', 'html', vipcard_buy_pagenotice, that, 0, app.globalData.systemInfo);
          that.setData({
            member_info,
            card_equity_list,
            card_list,
            is_open_vipcard_buy,
            modify_vipcard_name,
            is_vip_card_member,
            vipcard_unopen_headbg,
            vipcard_effect_headbg,
            vipcard_afterefect_headbg,
            vipcard_equity_notice,
            del_vip_day: res.data.del_vip_day || ''
          })
        }
      }
    })
  },

  choosecard: function (t) {
    this.setData({
      selectid: t.currentTarget.dataset.id
    });
  },

  submitpay: function (t) {
    if (wx.getStorageSync("token")) {
      var rech_id = this.data.selectid, token = wx.getStorageSync("token");
      if (void 0 == rech_id) return wx.showToast({
        icon: "none",
        title: "请选择要开通的会员类型"
      });
      app.util.request({
        url: "entry/wxapp/user",
        data: {
          controller: "vipcard.wxcharge",
          token,
          rech_id
        },
        dataType: "json",
        success: function (res) {
          wx.requestPayment({
            appId: res.data.appId,
            timeStamp: res.data.timeStamp,
            nonceStr: res.data.nonceStr,
            package: res.data.package,
            signType: res.data.signType,
            paySign: res.data.paySign,
            success: function (wxres) {
              wx.showToast({
                title: "支付成功",
                icon: "none",
                duration: 2000,
                success: function () {
                  setTimeout(function () {
                    wx.switchTab({
                      url: "/lionfish_comshop/pages/user/me"
                    });
                  }, 2000);
                }
              });
            },
            fail: function (error) {
              wx.showToast({
                icon: "none",
                title: "支付失败，请重试！"
              });
            }
          })
        }
      });
    } else{
      this.setData({
        needAuth: true
      });
    }
  }
})