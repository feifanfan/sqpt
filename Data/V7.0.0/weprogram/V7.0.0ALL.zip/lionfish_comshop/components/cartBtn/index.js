// lionfish_comshop/components/cartBtn/index.js
Component({
  externalClasses: ["i-class"],
  properties: {
    showHome: {
      type: Boolean,
      value: false
    },
    cartNum: {
      type: Number,
      value: 0
    }
  },

  methods: {
    goLink: function(e) {
      let url = e.currentTarget.dataset.link;
      wx.switchTab({ url })
    }
  }
})
