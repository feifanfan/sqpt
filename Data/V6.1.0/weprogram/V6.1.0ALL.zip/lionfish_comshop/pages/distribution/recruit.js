var app = getApp();
var util = require('../../utils/util.js');
var WxParse = require('../../wxParse/wxParse.js');
var status = require('../../utils/index.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    status.setNavBgColor();
    status.setGroupInfo().then((groupInfo) => {
      let commiss_diy_name = groupInfo && groupInfo.commiss_diy_name || '分销';
      wx.setNavigationBarTitle({
        title: `会员${commiss_diy_name}`,
      })
    });

    let that = this;
    if (!util.check_login()) {
      this.setData({
        needAuth: true
      })
    }
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'distribution.get_instruct'
      },
      dataType: 'json',
      success: function(res) {
        if (res.data.code == 0) {
          let article = res.data.content || '';
          WxParse.wxParse('article', 'html', article, that, 5);
        }
      }
    })
  },

  /**
   * 授权成功回调
   */
  authSuccess: function() {
    this.setData({
      needAuth: false
    })
  },

  subCommis: function() {
    wx.showLoading();
    var token = wx.getStorageSync('token');
    let that = this;
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'distribution.sub_commission_info',
        token
      },
      dataType: 'json',
      success: function (res) {
        wx.hideLoading();
        if (res.data.code == 0) {
          if (res.data.msg == "申请成功，平台将尽快审核"){
            wx.navigateTo({
              url: '/lionfish_comshop/pages/distribution/apply',
            })
          } else {
            wx.redirectTo({
              url: '/lionfish_comshop/pages/distribution/me',
            })
          }
        } else {
          if (res.data.msg=="请先登录"){
            that.setData({ needAuth: true })
            return;
          }
          if (res.data.msg == "您未填写表单！") {
            wx.navigateTo({
              url: '/lionfish_comshop/pages/distribution/apply',
            })
            return;
          }
          wx.showToast({
            title: res.data.msg ? res.data.msg:'申请失败，请重试！',
            icon: 'none'
          })
        }
      }
    })
  }

})