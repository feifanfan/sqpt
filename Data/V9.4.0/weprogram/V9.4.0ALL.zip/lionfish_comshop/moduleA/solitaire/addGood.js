var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabs: [{
        id: 0,
        name: '社区商品'
      },
      {
        id: 1,
        name: '仅快递'
      }
    ],
    currentIdx: 0,
    list: [],
    loadText: "加载中...",
    noData: 0,
    loadMore: true,
  },
  page: 1,

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let currentIdx = options.type || 0;
    let that = this;
    this.setData({
      currentIdx
    }, ()=>{
      that.getData();
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 切换导航
   */
  changeTabs: function(e) {
    let that = this;
    let currentIdx = e.currentTarget.dataset.type || 0;
    this.page = 1;
    this.setData({
      currentIdx,
      list: [],
      showEmpty: false,
      loadMore: true,
      loadOver: false
    }, () => {
      that.getData();
    })
  },

  /**
   * 获取列表
   */
  getData: function() {
    let that = this;
    const token = wx.getStorageSync('token');
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'solitaire.search_head_goodslist',
        token: token,
        page: this.page,
        is_only_express: this.data.currentIdx
      },
      dataType: 'json',
      success: function(res) {
        wx.hideLoading();
        if (res.data.code == 0) {
          let h = {};
          let list = res.data.data;
          if (list.length < 20) h.noMore = true;
          let oldList = that.data.list;
          list = oldList.concat(list);
          that.page++;
          that.setData({ list, ...h })
        } else if (res.data.code == 1) {
          // 无数据
          if (that.page == 1) that.setData({ noData: 1 })
          that.setData({ loadMore: false, noMore: false, loadText: "没有更多记录了~" })
        } else if (res.data.code == 2) {
          app.util.message('您还未登录', 'switchTo:/lionfish_comshop/pages/index/index', 'error');
          return;
        } else {
          app.util.message(res.data.msg, 'switchTo:/lionfish_comshop/pages/index/index', 'error');
          return;
        }
      }
    })
  },

  /**
   * type: 0单选 1多选
   */
  selectGoods: function(t){
    let currentIdx = this.data.currentIdx;
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2];  //上一个页面
    let goods = prevPage.data.goods || [];
    let goodsItem = t.detail;
    if(goods.length>0) {
      let idx = goods.findIndex(item => { return (item.gid == goodsItem.gid) })
      if (idx === -1) goods.push(goodsItem);
    } else {
      goods.push(goodsItem);
    }
    prevPage.setData({
      goods,
      type: currentIdx
    })
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (!this.data.loadMore) return false;
    this.getData();
  }
})