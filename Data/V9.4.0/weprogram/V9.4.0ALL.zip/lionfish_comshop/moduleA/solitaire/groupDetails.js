// 团长接龙详情
var app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    images_list: [
      'http://qiniu.liofis.com/images/3/2019/11/jjz0JUa8ONJsJcOUCwnjac2q3Qu8f6.jpg?imageView2/2/w/0/h/0/ignore-error/1',
      'http://qiniu.liofis.com/images/3/2019/11/y66PkKhyPjQkHbkPkSdcp6CSGMMkDk.jpg',
      'http://qiniu.liofis.com/images/3/2019/11/jjz0JUa8ONJsJcOUCwnjac2q3Qu8f6.jpg?imageView2/2/w/0/h/0/ignore-error/1',
      'http://qiniu.liofis.com/images/3/2019/11/y66PkKhyPjQkHbkPkSdcp6CSGMMkDk.jpg',
      'http://qiniu.liofis.com/images/3/2019/11/jjz0JUa8ONJsJcOUCwnjac2q3Qu8f6.jpg?imageView2/2/w/0/h/0/ignore-error/1',
      'http://qiniu.liofis.com/images/3/2019/11/y66PkKhyPjQkHbkPkSdcp6CSGMMkDk.jpg'
    ],
    showGoodsModal: false,
    showCommentModal: false,
    pid: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id = options.id || 0;
    if(id) {
      this.getData(id);
    } else {
      app.util.message('参数错误', 'switchTo:/lionfish_comshop/pages/index/index', 'error');
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 获取详情
   */
  getData: function (id) {
    // const token = wx.getStorageSync('token');
    let that = this;
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'solitaire.get_solitaire_detail',
        id
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          let { head_data, soli_info, solitaire_target, solitaire_target_takemember, solitaire_target_takemoney, solitaire_target_type } = res.data;
          var article = soli_info.content;
          WxParse.wxParse('article', 'html', article, that, 0, app.globalData.systemInfo);
          that.setData({
            community: head_data || '',
            soli_info,
            solitaire_target,
            solitaire_target_takemember,
            solitaire_target_takemoney,
            solitaire_target_type
          }, ()=>{
            that.visiteRecord();
          })
        } else if (res.data.code == 1) {
          app.util.message('您还未登录', 'switchTo:/lionfish_comshop/pages/index/index', 'error');
          return;
        } else {
          app.util.message(res.data.msg, 'switchTo:/lionfish_comshop/pages/index/index', 'error');
          return;
        }
      }
    })
  },

  showImgPrev: function (event){
    var idx = event ? event.currentTarget.dataset.idx : '';
    let urls = this.data.images_list;
    wx.previewImage({
      current: urls[idx],
      urls
    });
  },

  /**
   * 商品弹窗
   */
  handleGoodsModal: function(){
    this.setData({
      showGoodsModal: !this.data.showGoodsModal
    })
  },

  /**
   * 评论弹窗
   */
  handleCommentModal: function () {
    this.setData({
      showCommentModal: !this.data.showCommentModal
    })
  },

  subComment: function (e) {
    let { soli_info, pid } = this.data;
    let soli_id = soli_info.id || '';
    let content = e.detail.value.content || '';
    if (content=='') {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return;
    }
    let that = this;
    const token = wx.getStorageSync('token');
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'solitaire.sub_solipost',
        soli_id,
        content,
        pid,
        token
      },
      dataType: 'json',
      success: function (res) {
        if (res.data.code == 0) {
          // let post_id = res.data.post_id;
          that.setData({ content: '', showCommentModal: false })
          app.util.message(res.data.msg || '评价成功', '', 'success');
        } else {
          app.util.message(res.data.msg || '评价失败', '', 'error');
        }
      }
    })
  },

  /**
   * 记录浏览次数
   */
  visiteRecord: function () {
    let { soli_info } = this.data;
    let soli_id = soli_info.id || '';
    app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'solitaire.send_visite_record',
        soli_id
      },
      dataType: 'json',
      success: function (res) {}
    })
  },

  /**
   * 点赞
   */
  favComment: function (e) {
    let soli_info = this.data.soli_info;
    let soli_id = soli_info.id || '';
    let post_id = e ? e.currentTarget.dataset.post_id : '';
    post_id && app.util.request({
      url: 'entry/wxapp/index',
      data: {
        controller: 'solitaire.fav_soli_post',
        soli_id,
        post_id
      },
      dataType: 'json',
      success: function (res) {
        if(res.data.code==0) {
          if (res.data.do==1) {
            // 点赞成功
          } else {
            // 取消成功
          }
        }
      }
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})