var app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    spuItem: {
      type: Object,
      value: {}
    },
    idx: {
      type: Number,
      value: -1
    },
    type: {
      type: Number,
      value: 0
    },
    hasIpt: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    placeholdeImg: app.globalData.placeholdeImg
  },

  /**
   * 组件的方法列表
   */
  methods: {
    handleSelect: function(){
      this.triggerEvent("onSelect", this.data.spuItem);
    },
    handleDelete: function(){
      this.triggerEvent("onSelect", this.data.idx);
    }
  }
})
